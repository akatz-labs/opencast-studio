"""Simplified Environment - owns everything about a single ComfyUI environment."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import cached_property, wraps
from pathlib import Path
from typing import TYPE_CHECKING, cast

from ..analyzers.ref_diff_analyzer import RefDiffAnalyzer
from ..analyzers.status_scanner import StatusScanner
from ..constants import ACTIVE_TORCH_BACKEND_OVERRIDE_ENV
from ..factories.uv_factory import create_uv_for_environment
from ..logging.logging_config import get_logger
from ..managers.environment_git_orchestrator import EnvironmentGitOrchestrator
from ..managers.environment_model_manager import EnvironmentModelManager
from ..managers.git_manager import GitManager
from ..managers.model_symlink_manager import ModelSymlinkManager
from ..managers.node_manager import NodeManager
from ..managers.pyproject_manager import PyprojectManager
from ..managers.pytorch_backend_manager import PyTorchBackendManager
from ..managers.system_node_symlink_manager import SystemNodeSymlinkManager
from ..managers.user_content_symlink_manager import UserContentSymlinkManager
from ..managers.uv_project_manager import UVProjectManager
from ..managers.workflow_manager import WorkflowManager
from ..models.environment import EnvironmentStatus
from ..models.manifest import ManifestModel
from ..models.overlay import OVERLAY_TEMPLATE, OverlayConfig, OverlayInfo
from ..models.ref_diff import RefDiff
from ..models.runtime_config import (
    DependencyGroupRemovalResult,
    OverlayActivationResult,
    OverlayTemplateResult,
    TorchBackendDetection,
    TorchBackendSelection,
    TorchBackendStatus,
    UVCommandContext,
)
from ..models.shared import (
    ManagerStatus,
    ManagerUpdateResult,
    ModelSourceResult,
    ModelSourceStatus,
    NodeDevLinkResult,
    NodeInfo,
    NodeRemovalResult,
    UpdateResult,
)
from ..models.sync import SyncResult
from ..strategies.confirmation import ConfirmationStrategy
from ..utils.common import run_command
from ..utils.environment_lock import EnvironmentOperationLock
from ..utils.filesystem import rmtree
from ..utils.node_identity import resolve_installed_node_alias
from ..utils.requirements import read_comfyui_requirements_with_supplements
from ..validation.resolution_tester import ResolutionTester

if TYPE_CHECKING:
    from comfygit_core.core.workspace import Workspace
    from comfygit_core.models.git import (
        GitBranch,
        GitCommitSummary,
        GitRemote,
        GitSyncStatus,
    )
    from comfygit_core.models.protocols import (
        ExportCallbacks,
        ImportCallbacks,
        ModelResolutionStrategy,
        NodeResolutionStrategy,
        RollbackStrategy,
        SyncCallbacks,
    )

    from ..caching.workflow_cache import WorkflowCacheRepository
    from ..models.dependency_resolution import (
        DependencyResolutionAcceptance,
        DependencyResolutionApplyResult,
        DependencyResolutionPreview,
    )
    from ..models.lifecycle import (
        EnvironmentLifecycleStatus,
        LifecycleOperationState,
        LifecycleRuntimeState,
    )
    from ..models.manifest import (
        EnvironmentManifestSnapshot,
        ManifestWorkflowEntry,
        ManifestWorkflowModel,
    )
    from ..models.merge_plan import MergeResult, MergeValidation
    from ..models.readiness import EnvironmentReadiness, ModelSourceCandidate
    from ..models.workflow import (
        BatchDownloadCallbacks,
        DetailedWorkflowStatus,
        NodeInstallCallbacks,
        NodeResolutionContext,
        ResolutionResult,
        ResolvedNodePackage,
        ScoredMatch,
        ScoredPackageMatch,
        WorkflowDependencies,
        WorkflowNode,
        WorkflowSyncStatus,
    )
    from ..models.workflow_contract import WorkflowExecutionContract
    from ..services.model_downloader import DownloadRequest, DownloadResult
    from ..services.node_lookup_service import NodeLookupService

logger = get_logger(__name__)
UTC = timezone.utc


def _workflow_api_prompt_relpath(workflow_name: str) -> Path:
    safe_name = re.sub(r"[^A-Za-z0-9._ -]+", "_", workflow_name).strip()
    safe_name = safe_name or "workflow"
    return Path("workflow_api") / f"{safe_name}.api.json"


def _requires_env_lock(method):
    @wraps(method)
    def wrapper(self, *args, **kwargs):
        with self._operation_lock.named(method.__name__):
            return method(self, *args, **kwargs)
    return wrapper


class Environment:
    """A ComfyUI environment - manages its own state through pyproject.toml."""

    def __init__(
        self,
        name: str,
        path: Path,
        workspace: Workspace,
        torch_backend: str | None = None,
    ):
        self.name = name
        self.path = path
        self.workspace = workspace
        self.torch_backend = torch_backend

        # Workspace-level paths
        self.workspace_paths = workspace.paths
        self.global_models_path = workspace.workspace_config_manager.get_models_directory()

        # Workspace-level services
        self.model_repository = workspace.model_repository
        self.node_mapping_repository = workspace.node_mapping_repository
        self.comfyui_builtin_versions_repository = (
            workspace.comfyui_builtin_versions_repository
        )
        self.workspace_config_manager = workspace.workspace_config_manager
        self.model_downloader = workspace.model_downloader

        # Core paths
        self.cec_path = path / ".cec"
        self.pyproject_path = self.cec_path / "pyproject.toml"
        self.comfyui_path = path / "ComfyUI"
        self.custom_nodes_path = self.comfyui_path / "custom_nodes"
        self.venv_path = path / ".venv"
        self.models_path = self.comfyui_path / "models"

        # Guard against concurrent mutations of this environment.
        self._operation_lock = EnvironmentOperationLock(self.path / ".comfygit.lock")

    @classmethod
    def from_path(
        cls,
        path: Path,
        workspace: Workspace,
        *,
        name: str | None = None,
        torch_backend: str | None = None,
    ) -> Environment:
        """Construct an environment object when the caller already has a path.

        Normal callers should prefer ``workspace.get_environment(name)`` or
        ``workspace.create_environment(name)``. This classmethod exists for
        advanced embedding and tests that already resolved the environment
        directory.
        """
        resolved_path = path.resolve()
        return cls(
            name=name or resolved_path.name,
            path=resolved_path,
            workspace=workspace,
            torch_backend=torch_backend,
        )

    ## Cached properties ##
    #
    # Orchestrators coordinate git and model operations with environment state:
    # - git_orchestrator: Wraps git operations with node reconciliation + package sync + workflow restore
    # - model_manager: Coordinates model operations across pyproject, repository, and downloader
    #
    # This pattern keeps environment.py thin by delegating complex multi-step operations.

    @cached_property
    def uv_manager(self) -> UVProjectManager:
        return create_uv_for_environment(
            self.workspace_paths.root,
            cec_path=self.cec_path,
            venv_path=self.venv_path,
            torch_backend=self.torch_backend,
            external_uv_cache=self.workspace_config_manager.get_external_uv_cache(),
        )

    @cached_property
    def pyproject(self) -> PyprojectManager:
        return PyprojectManager(self.pyproject_path)

    @cached_property
    def pytorch_manager(self) -> PyTorchBackendManager:
        return PyTorchBackendManager(self.cec_path)

    @cached_property
    def overlay_manager(self):
        """Overlay manager bound to this environment's UV manager."""
        return self.uv_manager.overlay_manager

    @cached_property
    def node_lookup(self) -> NodeLookupService:
        from ..services.node_lookup_service import NodeLookupService
        return NodeLookupService(
            cache_path=self.workspace_paths.cache,
            node_mappings_repository=self.node_mapping_repository,
            workspace_config=self.workspace_config_manager,
        )

    @cached_property
    def resolution_tester(self) -> ResolutionTester:
        return ResolutionTester(self.workspace_paths.root)

    @cached_property
    def package_config(self):
        """Get package configuration manager for substitutions and exclusions."""
        from ..configs.package_config import PackageConfigManager
        return PackageConfigManager(self.cec_path)

    def get_sync_extras(self) -> list[str]:
        """Get default optional extras installed during sync."""
        return self.pyproject.get_sync_extras()

    def add_sync_extra(self, extra: str) -> bool:
        """Add a default optional extra (returns True if added)."""
        return self.pyproject.add_sync_extra(extra)

    def remove_sync_extra(self, extra: str) -> bool:
        """Remove a default optional extra (returns True if removed)."""
        return self.pyproject.remove_sync_extra(extra)

    # =====================================================
    # Local Runtime Configuration
    # =====================================================

    def get_python_version(self, default: str = "3.12") -> str:
        """Return the configured Python version for this environment."""
        python_version_file = self.cec_path / ".python-version"
        if python_version_file.exists():
            return python_version_file.read_text(encoding="utf-8").strip()
        return default

    def is_valid_torch_backend(self, backend: str) -> bool:
        """Return whether a PyTorch backend string has a supported format."""
        return self.pytorch_manager.is_valid_backend(backend)

    def get_torch_backend_status(self) -> TorchBackendStatus:
        """Return local PyTorch backend state without mutating configuration."""
        has_backend = self.pytorch_manager.has_backend()
        backend: str | None = None
        versions: Mapping[str, str] = {}
        if has_backend:
            backend = self.pytorch_manager.get_backend()
            versions = self.pytorch_manager.get_versions()

        return TorchBackendStatus(
            backend=backend,
            versions=versions,
            backend_file=self.pytorch_manager.backend_file,
            is_configured=has_backend,
        )

    def ensure_torch_backend(
        self,
        python_version: str | None = None,
        override: str | None = None,
    ) -> TorchBackendSelection:
        """Return an explicit or configured backend, probing when no backend is configured."""
        if override:
            return TorchBackendSelection(
                backend=override,
                versions={},
                backend_file=self.pytorch_manager.backend_file,
                is_configured=self.pytorch_manager.has_backend(),
                was_probed=False,
            )

        had_backend = self.pytorch_manager.has_backend()
        backend = self.pytorch_manager.ensure_backend(
            python_version or self.get_python_version()
        )
        return TorchBackendSelection(
            backend=backend,
            versions=self.pytorch_manager.get_versions(),
            backend_file=self.pytorch_manager.backend_file,
            is_configured=True,
            was_probed=not had_backend,
        )

    def set_torch_backend(
        self,
        backend: str,
        python_version: str | None = None,
    ) -> TorchBackendStatus:
        """Probe and persist a local PyTorch backend selection."""
        if not self.pytorch_manager.is_valid_backend(backend):
            raise ValueError(f"Invalid PyTorch backend: {backend}")
        self.pytorch_manager.probe_and_set_backend(
            python_version or self.get_python_version(),
            backend,
        )
        return self.get_torch_backend_status()

    def detect_torch_backend(self, python_version: str | None = None) -> TorchBackendDetection:
        """Probe the recommended backend without persisting it."""
        from ..utils.pytorch_prober import probe_pytorch_versions

        resolved_python = python_version or self.get_python_version()
        versions, backend = probe_pytorch_versions(resolved_python, "auto")
        return TorchBackendDetection(
            backend=backend,
            versions=versions,
            python_version=resolved_python,
        )

    def list_overlays(self, *, active_only: bool = False) -> list[OverlayInfo]:
        """Return discovered overlays without exposing the overlay manager."""
        overlays = self.overlay_manager.list_overlays()
        if active_only:
            return [overlay for overlay in overlays if overlay.is_active]
        return overlays

    def get_overlay(self, name: str) -> OverlayConfig:
        """Resolve and load an overlay by user-provided name."""
        resolved_name = self.overlay_manager.resolve_overlay_name(name)
        return self.overlay_manager.load_overlay(resolved_name)

    def enable_overlay(self, name: str) -> OverlayActivationResult:
        """Enable an overlay in local activation config."""
        resolved_name = self.overlay_manager.resolve_overlay_name(name)
        active_names = self.overlay_manager.get_active_names()
        active_keys = {active.lower() for active in active_names}
        is_compatible = self.overlay_manager.is_overlay_compatible(resolved_name)
        if resolved_name.lower() in active_keys:
            return OverlayActivationResult(
                name=resolved_name,
                changed=False,
                is_compatible=is_compatible,
            )

        self.overlay_manager.set_active_names(active_names + [resolved_name])
        return OverlayActivationResult(
            name=resolved_name,
            changed=True,
            is_compatible=is_compatible,
        )

    def disable_overlay(self, name: str) -> OverlayActivationResult:
        """Disable an overlay in local activation config."""
        resolved_name = self.overlay_manager.resolve_overlay_name(name)
        active_names = self.overlay_manager.get_active_names()
        filtered = [
            active
            for active in active_names
            if active.lower() != resolved_name.lower()
        ]
        is_compatible = self.overlay_manager.is_overlay_compatible(resolved_name)
        if len(filtered) == len(active_names):
            return OverlayActivationResult(
                name=resolved_name,
                changed=False,
                is_compatible=is_compatible,
            )

        self.overlay_manager.set_active_names(filtered)
        return OverlayActivationResult(
            name=resolved_name,
            changed=True,
            is_compatible=is_compatible,
        )

    def create_overlay_template(
        self,
        name: str | None = None,
        *,
        local: bool = False,
    ) -> OverlayTemplateResult:
        """Create a shared or local overlay template file."""
        if name is None:
            if not local:
                raise ValueError("Overlay name is required (or use local=True for .local.toml)")
            name = ".local"
        elif local and not name.startswith("."):
            name = f".{name}"

        OverlayConfig.validate_name(name)
        overlay_path = self.cec_path / "overlays" / f"{name}.toml"
        scope = "local" if name.startswith(".") else "shared"
        if overlay_path.exists():
            return OverlayTemplateResult(
                name=name,
                path=overlay_path,
                scope=scope,
                created=False,
            )
        overlay_path.parent.mkdir(parents=True, exist_ok=True)
        overlay_path.write_text(OVERLAY_TEMPLATE, encoding="utf-8")
        return OverlayTemplateResult(
            name=name,
            path=overlay_path,
            scope=scope,
            created=True,
        )

    def get_runtime_python(self) -> Path:
        """Return the Python executable uv uses for this environment."""
        return self.uv_manager.python_executable

    def _get_runtime_package_details(self, package: str) -> str:
        """Return `uv pip show` output for an installed runtime package."""
        return self.uv_manager.show_package(package, self.get_runtime_python())

    def get_runtime_package_version(self, package: str) -> str | None:
        """Return the installed version for a runtime package, if it can be parsed."""
        package_details = self._get_runtime_package_details(package)
        match = re.search(r"^Version:\s*(.+)$", package_details, re.MULTILINE)
        if not match:
            return None
        return match.group(1).strip()

    def get_manifest_path(self) -> Path:
        """Return the portable manifest path for this environment."""
        return self.pyproject.path

    def load_manifest_config(self) -> Mapping[str, object]:
        """Load the raw manifest document for display/serialization adapters."""
        return self.pyproject.load()

    def remove_dependencies_from_group(
        self,
        group: str,
        packages: Sequence[str],
    ) -> DependencyGroupRemovalResult:
        """Remove packages from a dependency group without exposing pyproject internals."""
        result = self.pyproject.dependencies.remove_from_group(group, list(packages))
        return DependencyGroupRemovalResult(
            removed=list(result["removed"]),
            skipped=list(result["skipped"]),
        )

    def remove_dependency_group(self, group: str) -> None:
        """Remove an entire dependency group from the manifest."""
        if not self.pyproject.manifest.remove_dependency_group(group):
            raise ValueError(f"Group '{group}' not found")

    def get_uv_command_context(self) -> UVCommandContext:
        """Return environment-scoped uv command context for CLI passthrough."""
        return UVCommandContext(
            binary=self.uv_manager.uv._binary,
            cwd=self.cec_path,
            env={
                **os.environ,
                "UV_PROJECT_ENVIRONMENT": str(self.venv_path),
                "UV_CACHE_DIR": str(self.workspace_paths.cache / "uv_cache"),
            },
        )

    @cached_property
    def node_manager(self) -> NodeManager:
        return NodeManager(
            self.pyproject,
            self.uv_manager,
            self.node_lookup,
            self.resolution_tester,
            self.custom_nodes_path,
            self.node_mapping_repository,
            self.pytorch_manager,
            self.package_config,
        )

    @cached_property
    def model_symlink_manager(self) -> ModelSymlinkManager:
        """Get model symlink manager."""
        return ModelSymlinkManager(
            self.comfyui_path, self.global_models_path
        )

    @cached_property
    def user_content_manager(self) -> UserContentSymlinkManager:
        """Get user content symlink manager for input/output directories."""
        return UserContentSymlinkManager(
            self.comfyui_path,
            self.name,
            self.workspace_paths.input,
            self.workspace_paths.output,
        )

    @cached_property
    def system_node_manager(self) -> SystemNodeSymlinkManager:
        """Get system node symlink manager for workspace-level infrastructure nodes."""
        return SystemNodeSymlinkManager(
            self.comfyui_path,
            self.workspace_paths.system_nodes,
        )

    def ensure_system_node_links(self) -> list[str]:
        """Ensure workspace-level system nodes are linked into this environment.

        Adapters should use this facade instead of importing the underlying
        symlink manager.
        """
        return self.system_node_manager.create_symlinks()

    @cached_property
    def workflow_cache(self) -> WorkflowCacheRepository:
        """Get workflow cache repository."""
        from ..caching.workflow_cache import WorkflowCacheRepository
        cache_db_path = self.workspace_paths.cache / "workflows.db"
        return WorkflowCacheRepository(
            cache_db_path,
            pyproject_manager=self.pyproject,
            model_repository=self.model_repository,
            workspace_config_manager=self.workspace_config_manager,
            cec_path=self.cec_path,
            node_mapping_repository=self.node_mapping_repository,
            builtin_versions_repository=self.comfyui_builtin_versions_repository,
        )

    @cached_property
    def workflow_manager(self) -> WorkflowManager:
        return WorkflowManager(
            self.comfyui_path,
            self.cec_path,
            self.pyproject,
            self.model_repository,
            self.node_mapping_repository,
            self.model_downloader,
            self.workflow_cache,
            self.name,
            builtin_versions_repository=self.comfyui_builtin_versions_repository,
        )

    @cached_property
    def git_manager(self) -> GitManager:
        return GitManager(self.cec_path)

    @cached_property
    def git_orchestrator(self) -> EnvironmentGitOrchestrator:
        """Get environment-aware git orchestrator."""
        return EnvironmentGitOrchestrator(
            git_manager=self.git_manager,
            node_manager=self.node_manager,
            pyproject_manager=self.pyproject,
            uv_manager=self.uv_manager,
            workflow_manager=self.workflow_manager,
            pytorch_manager=self.pytorch_manager,
        )

    @cached_property
    def model_manager(self) -> EnvironmentModelManager:
        """Get environment model manager."""
        return EnvironmentModelManager(
            pyproject=self.pyproject,
            model_repository=self.model_repository,
            model_downloader=self.model_downloader,
        )

    ## Helper methods ##

    ## Public methods ##

    # =====================================================
    # Environment Management
    # =====================================================

    def _get_active_torch_backend_override(self) -> str | None:
        """Return the non-persistent backend override active for this process."""
        backend = os.environ.get(ACTIVE_TORCH_BACKEND_OVERRIDE_ENV)
        if not backend:
            return None

        if self.is_valid_torch_backend(backend):
            return backend

        logger.warning(
            "Ignoring invalid %s=%r",
            ACTIVE_TORCH_BACKEND_OVERRIDE_ENV,
            backend,
        )
        return None

    def status(self) -> EnvironmentStatus:
        """Get environment sync and git status."""
        git_status = self.git_manager.get_status(self.pyproject)
        active_backend_override = self._get_active_torch_backend_override()

        # Each subsystem provides its complete status
        scanner = StatusScanner(
            comfyui_path=self.comfyui_path,
            venv_path=self.venv_path,
            uv=self.uv_manager,
            pyproject=self.pyproject,
            pytorch_manager=self.pytorch_manager,
        )
        comparison = scanner.get_full_comparison(
            check_package_sync=git_status.has_dependency_changes,
            backend_override=active_backend_override,
        )

        workflow_status = self.workflow_manager.get_workflow_status()

        # Detect missing models
        missing_models = self.model_manager.detect_missing_models()

        # Assemble final status
        return EnvironmentStatus.create(
            comparison=comparison,
            git_status=git_status,
            workflow_status=workflow_status,
            missing_models=missing_models
        )

    def _missing_required_materialized_nodes(self) -> list[str]:
        """Return required manifest nodes absent from the ComfyUI checkout."""
        scanner = StatusScanner(
            comfyui_path=self.comfyui_path,
            venv_path=self.venv_path,
            uv=self.uv_manager,
            pyproject=self.pyproject,
            pytorch_manager=self.pytorch_manager,
        )
        comparison = scanner.get_full_comparison(check_package_sync=False)
        missing = {
            str(name).casefold()
            for name in (
                *comparison.missing_nodes,
                *comparison.dev_nodes_missing,
            )
        }
        required = []
        for node in self.pyproject.nodes.get_existing().values():
            if node.criticality == "optional":
                continue
            if node.name.casefold() in missing:
                required.append(node.name)
        return sorted(required, key=str.casefold)

    def get_lifecycle_status(
        self,
        *,
        status: EnvironmentStatus | None = None,
        include_readiness: bool = False,
        runtime_state: LifecycleRuntimeState | None = None,
        operation_state: LifecycleOperationState | None = None,
    ) -> EnvironmentLifecycleStatus:
        """Return composed lifecycle health and recommended actions.

        This facade keeps adapters on the public Environment API. Core computes
        manifest/filesystem/snapshot/workspace-index signals from existing
        status/readiness paths; Manager or CLI may pass runtime/operation state
        that only the adapter can observe.
        """
        from ..services.environment_lifecycle import (
            build_lifecycle_status_from_environment_status,
        )
        from ..utils.git import git_rev_parse

        readiness = self.get_readiness() if include_readiness else None
        return build_lifecycle_status_from_environment_status(
            status or self.status(),
            environment_name=self.name,
            workspace_path=str(self.workspace_paths.root),
            current_commit=git_rev_parse(self.cec_path, "HEAD"),
            readiness=readiness,
            runtime_state=runtime_state,
            operation_state=operation_state,
        )

    def get_manager_status(self) -> ManagerStatus:
        """Check current comfygit-manager installation status.

        Returns ManagerStatus with:
        - current_version: Version from pyproject.toml or detected from filesystem
        - latest_version: Latest version from ComfyUI Registry
        - update_available: Whether latest > current
        - is_legacy: True if manager is symlinked (legacy workspace)
        - is_tracked: True if manager is tracked in pyproject.toml
        - status: "headless", "legacy", "not_installed", "outdated", or "up_to_date"
        """
        from packaging.version import InvalidVersion, Version

        from ..constants import MANAGER_NODE_ID
        from ..utils.symlink_utils import is_link

        # Explicit headless marker takes precedence over manager install checks.
        if self._is_headless_mode():
            return ManagerStatus(
                current_version=None,
                latest_version=None,
                update_available=False,
                is_legacy=False,
                is_tracked=False,
                status="headless",
            )

        current_version: str | None = None
        is_legacy = False
        is_tracked = False

        # First check if tracked in pyproject (modern per-env manager)
        nodes = self.pyproject.nodes.get_existing()
        if MANAGER_NODE_ID in nodes:
            is_tracked = True
            current_version = nodes[MANAGER_NODE_ID].version
        else:
            # Not tracked - check for legacy symlink at registry ID path
            legacy_path = self.custom_nodes_path / MANAGER_NODE_ID
            if is_link(legacy_path):
                is_legacy = True
                # Try to read version from symlink target
                try:
                    from ..utils.toml_compat import tomllib
                    target_pyproject = legacy_path / "pyproject.toml"
                    if target_pyproject.exists():
                        with open(target_pyproject, "rb") as f:
                            data = tomllib.load(f)
                            current_version = data.get("project", {}).get("version")
                except Exception:
                    pass

        # Get latest version from registry
        latest_version: str | None = None
        try:
            node_info = self.node_lookup.get_node(MANAGER_NODE_ID)
            if node_info:
                latest_version = node_info.version
        except Exception:
            # Registry lookup failed - continue without latest
            pass

        # Determine if update is available
        update_available = False
        if current_version and latest_version:
            try:
                update_available = Version(latest_version) > Version(current_version)
            except InvalidVersion:
                # Version comparison failed - assume update available if versions differ
                update_available = latest_version != current_version

        status_name = "up_to_date"
        if is_legacy:
            status_name = "legacy"
        elif not is_tracked:
            status_name = "not_installed"
        elif update_available:
            status_name = "outdated"

        return ManagerStatus(
            current_version=current_version,
            latest_version=latest_version,
            update_available=update_available,
            is_legacy=is_legacy,
            is_tracked=is_tracked,
            status=status_name,
        )

    @_requires_env_lock
    def update_manager(
        self,
        version: str = "latest",
        confirmation_strategy: ConfirmationStrategy | None = None,
    ) -> ManagerUpdateResult:
        """Update comfygit-manager with migration support.

        Handles:
        1. Legacy symlink → tracked node migration
        2. Cleanup of dependency-groups.system-nodes
        3. Standard registry node update flow
        4. Schema version bump on first migration

        Args:
            version: Target version ("latest" or specific version)
            confirmation_strategy: Strategy for confirming changes

        Returns:
            ManagerUpdateResult with details of what changed
        """
        from ..constants import MANAGER_NODE_ID
        from ..utils.symlink_utils import is_link

        manager_path = self.custom_nodes_path / MANAGER_NODE_ID
        status = self.get_manager_status()

        # Ensure PyTorch backend is configured (auto-probe if missing)
        python_version_file = self.cec_path / ".python-version"
        python_version = (
            python_version_file.read_text(encoding="utf-8").strip()
            if python_version_file.exists()
            else "3.12"
        )
        self.pytorch_manager.ensure_backend(python_version)

        old_version = status.current_version
        was_migration = False

        # Handle legacy symlink migration
        if status.is_legacy:
            # Remove symlink - we'll install fresh
            if is_link(manager_path):
                manager_path.unlink()
            was_migration = True

        # Check if already tracked
        nodes = self.pyproject.nodes.get_existing()
        if MANAGER_NODE_ID in nodes and not was_migration:
            # Standard update flow, optionally pinned to a caller-selected version.
            result = self.node_manager.update_node(
                MANAGER_NODE_ID,
                confirmation_strategy=confirmation_strategy,
                target_version=None if version == "latest" else version,
            )

            # Cleanup legacy dependency group if present
            self._cleanup_system_nodes_dependency_group()
            self._clear_headless_marker()

            return ManagerUpdateResult(
                changed=result.changed,
                was_migration=False,
                old_version=result.old_version,
                new_version=result.new_version,
                message=result.message,
            )

        # Not tracked or migrating - add as new node
        node_info = self.node_manager.add_node(
            identifier=MANAGER_NODE_ID if version == "latest" else f"{MANAGER_NODE_ID}@{version}",
        )

        # Cleanup legacy dependency group
        self._cleanup_system_nodes_dependency_group()
        self._clear_headless_marker()

        # Bump workspace schema if this was a migration
        if was_migration and self.workspace.is_legacy_schema():
            self.workspace._write_schema_version()

        return ManagerUpdateResult(
            changed=True,
            was_migration=was_migration,
            old_version=old_version,
            new_version=node_info.version,
            message="Migrated to per-environment manager" if was_migration else f"Installed {MANAGER_NODE_ID}",
        )

    def _cleanup_system_nodes_dependency_group(self) -> None:
        """Remove legacy dependency-groups.system-nodes from pyproject.toml."""
        if self.pyproject.manifest.remove_dependency_group("system-nodes"):
            logger.info("Removed legacy dependency-groups.system-nodes")

    def _is_headless_mode(self) -> bool:
        """Return True when this environment was created/imported with --no-manager."""
        return self.pyproject.manifest.is_headless()

    def _set_headless_marker(self) -> None:
        """Persist headless marker in pyproject.toml."""
        self.pyproject.manifest.set_headless()

    def _prepare_headless_import(self) -> None:
        """Prepare imported/materialized environments that should not load Manager."""
        from ..constants import MANAGER_NODE_ID

        if self.pyproject.nodes.remove(MANAGER_NODE_ID):
            logger.info("Removed comfygit-manager from headless environment manifest")
        self._set_headless_marker()

    def _clear_headless_marker(self) -> None:
        """Remove headless marker after manager installation."""
        self.pyproject.manifest.clear_headless()

    def _register_imported_manager(self) -> None:
        """Auto-register or install comfygit-manager for imported environment.

        Order of operations:
        1. If tracked in pyproject.toml → already good, skip
        2. If directory exists (from export) → register with detected version
        3. If missing entirely → install fresh from registry

        This replaces the legacy symlink system where manager was symlinked from
        workspace-level .metadata/system_nodes/.
        """
        from ..constants import MANAGER_NODE_ID

        # Check if already tracked
        nodes = self.pyproject.nodes.get_existing()
        if MANAGER_NODE_ID in nodes:
            logger.debug("comfygit-manager already tracked in pyproject.toml")
            return

        manager_path = self.custom_nodes_path / MANAGER_NODE_ID

        if manager_path.exists() and manager_path.is_dir():
            # Directory exists - register from filesystem
            self._register_existing_manager(manager_path)
        else:
            # Not present - install fresh from registry
            self._install_manager_from_registry()

        # Always cleanup legacy dependency group
        self._cleanup_system_nodes_dependency_group()

    def _register_existing_manager(self, manager_path: Path) -> None:
        """Register existing manager directory in pyproject.toml."""
        from ..constants import MANAGER_NODE_ID
        from ..utils.toml_compat import tomllib

        # Detect version from manager's pyproject.toml
        version = None
        manager_pyproject = manager_path / "pyproject.toml"
        if manager_pyproject.exists():
            try:
                with open(manager_pyproject, "rb") as f:
                    data = tomllib.load(f)
                    version = data.get("project", {}).get("version")
            except Exception as e:
                logger.warning(f"Could not read manager version: {e}")

        self.pyproject.manifest.register_node(
            MANAGER_NODE_ID,
            NodeInfo(
                name=MANAGER_NODE_ID,
                version=version or "unknown",
                source="registry",
                registry_id=MANAGER_NODE_ID,
            ),
        )
        logger.info(f"Registered existing comfygit-manager (v{version or 'unknown'})")

    def _install_manager_from_registry(self) -> None:
        """Install comfygit-manager from registry during import."""
        from ..constants import MANAGER_NODE_ID

        logger.info("Installing comfygit-manager from registry...")
        try:
            self.node_manager.add_node(MANAGER_NODE_ID)
            logger.info("comfygit-manager installed successfully")

            # Upgrade workspace schema if this is a legacy workspace
            if self.workspace.upgrade_schema_if_needed():
                logger.info("Upgraded workspace to schema v2")
        except Exception as e:
            # Manager installation failure is non-fatal
            logger.warning(f"Could not install comfygit-manager: {e}")
            logger.warning("Environment will work but manager panel will be unavailable")

    def _ensure_schema_migrated(self) -> bool:
        """Migrate pyproject schema v1 → v2 if needed.

        Schema v1 has PyTorch config embedded in [tool.uv] section.
        Schema v2 materializes PyTorch config from .pytorch-backend only in disposable sync projects.

        This migration:
        1. Strips embedded [tool.uv] PyTorch config
        2. Updates schema_version to 2

        Note: Does NOT persist .pytorch-backend. User must explicitly
        set backend with 'cg env-config torch-backend set'.

        Returns:
            True if migration was performed, False if already migrated
        """
        migrated = self.pyproject.migrate_pytorch_config()
        if migrated:
            logger.info("Migrated environment to schema v2 (stripped PyTorch config)")

        # Always ensure .pytorch-backend and uv.lock are in .gitignore (handles pulls from older remotes)
        self.pytorch_manager._ensure_gitignore_entry()
        self.git_manager.ensure_gitignore_entry("uv.lock")
        self.git_manager.ensure_gitignore_entry("backups/")
        self.git_manager.ensure_gitignore_entry(".comfygit-tmp/")
        self.git_manager.ensure_gitignore_entry("comfyui_builtins.json")
        self.git_manager.ensure_gitignore_entry("comfyui_folder_paths.json")
        self.git_manager.ensure_gitignore_entry("comfyui_model_loaders.json")
        self._untrack_uvlock_if_tracked()
        self._untrack_generated_metadata_if_tracked()

        return migrated

    @_requires_env_lock
    def sync(
        self,
        dry_run: bool = False,
        model_strategy: str = "skip",
        model_callbacks: BatchDownloadCallbacks | None = None,
        node_callbacks: NodeInstallCallbacks | None = None,
        remove_extra_nodes: bool = True,
        sync_callbacks: SyncCallbacks | None = None,
        verbose: bool = False,
        preserve_workflows: bool = False,
        backend_override: str | None = None,
        overlay_names: list[str] | None = None,
        extras: list[str] | None = None,
        all_extras: bool = False,
        mark_complete: bool = True,
    ) -> SyncResult:
        """Apply changes: sync packages, nodes, workflows, and models with environment.

        Args:
            dry_run: If True, don't actually apply changes
            model_strategy: Model download strategy - "all", "required", or "skip" (default: skip)
            model_callbacks: Optional callbacks for model download progress
            node_callbacks: Optional callbacks for node installation progress
            remove_extra_nodes: If True, remove extra nodes. If False, only warn (default: True)
            verbose: If True, show uv output in real-time during dependency installation
            preserve_workflows: If True, preserve uncommitted workflows during restore.
                               Use True for runtime restarts (exit code 42) to keep user edits.
                               Use False (default) for git operations and repairs.
            backend_override: Override PyTorch backend instead of reading from file (e.g., "cu128")
            overlay_names: One-time overlay names for this sync call.
            extras: Optional list of extras to install
            all_extras: Install all optional extras
            mark_complete: False when import still has acquisition steps to finish.

        Returns:
            SyncResult with details of what was synced

        Raises:
            UVCommandError: If sync fails
        """
        from ..services.environment_sync_coordinator import EnvironmentSyncCoordinator

        effective_backend_override = (
            backend_override or self._get_active_torch_backend_override()
        )

        return EnvironmentSyncCoordinator(self).sync(
            dry_run=dry_run,
            model_strategy=model_strategy,
            model_callbacks=model_callbacks,
            node_callbacks=node_callbacks,
            remove_extra_nodes=remove_extra_nodes,
            sync_callbacks=sync_callbacks,
            verbose=verbose,
            preserve_workflows=preserve_workflows,
            backend_override=effective_backend_override,
            overlay_names=overlay_names,
            extras=extras,
            all_extras=all_extras,
            mark_complete=mark_complete,
        )

    # =====================================================
    # Pull/Merge Preview
    # =====================================================

    def preview_pull(
        self,
        remote: str = "origin",
        branch: str | None = None,
    ) -> RefDiff:
        """Preview what changes a pull operation would bring.

        Fetches from remote and compares to show what nodes, models,
        workflows, and dependencies would change.

        Args:
            remote: Remote name (default: origin)
            branch: Branch to pull (default: current branch)

        Returns:
            RefDiff showing all changes

        Raises:
            ValueError: If remote branch doesn't exist
        """
        from ..utils.git import git_fetch, git_get_current_branch, git_rev_parse

        # Fetch to update remote refs
        git_fetch(self.cec_path, remote)

        # Determine target ref
        current_branch = branch or git_get_current_branch(self.cec_path)
        target_ref = f"{remote}/{current_branch}"

        # Check if remote branch exists
        if not git_rev_parse(self.cec_path, target_ref):
            raise ValueError(
                f"Remote branch '{target_ref}' doesn't exist.\n"
                f"The remote '{remote}' may not have a branch named '{current_branch}'.\n"
                f"  • Check available branches: git branch -r\n"
                f"  • Push this branch first: cg push -r {remote}"
            )

        # Analyze diff
        analyzer = RefDiffAnalyzer(self.cec_path)
        return analyzer.analyze(base_ref="HEAD", target_ref=target_ref)

    def preview_merge(self, branch: str) -> RefDiff:
        """Preview what changes merging a branch would bring.

        Args:
            branch: Branch to merge

        Returns:
            RefDiff showing all changes and conflicts
        """
        analyzer = RefDiffAnalyzer(self.cec_path)
        return analyzer.analyze(base_ref="HEAD", target_ref=branch, detect_conflicts=True)

    @_requires_env_lock
    def pull_and_repair(
        self,
        remote: str = "origin",
        branch: str | None = None,
        model_strategy: str = "all",
        model_callbacks: BatchDownloadCallbacks | None = None,
        node_callbacks: NodeInstallCallbacks | None = None,
        strategy_option: str | None = None,
        force: bool = False,
        backend_override: str | None = None,
        token: str | None = None,
    ) -> dict:
        """Pull from remote and auto-repair environment (atomic operation).

        If sync fails, git changes are rolled back automatically.
        This ensures the environment is never left in a half-pulled state.

        Args:
            remote: Remote name (default: origin)
            branch: Branch to pull (default: current)
            model_strategy: Model download strategy ("all", "required", "skip")
            model_callbacks: Optional callbacks for model download progress
            node_callbacks: Optional callbacks for node installation progress
            strategy_option: Optional git merge strategy (e.g., "ours" or "theirs")
            force: If True, discard uncommitted changes and allow unrelated histories
            backend_override: Override PyTorch backend for sync (e.g., "cu128")
            token: Optional HTTPS token for authenticated fetch/pull operations

        Returns:
            Dict with pull results and sync_result

        Raises:
            CDEnvironmentError: If uncommitted changes exist (without force) or sync fails
            ValueError: If merge conflicts
            OSError: If pull or repair fails
        """
        from ..models.exceptions import CDEnvironmentError
        from ..utils.git import git_reset_hard, git_rev_parse

        # Check for uncommitted changes
        if self.git_manager.has_uncommitted_changes():
            if force:
                # Force mode: discard uncommitted changes
                logger.warning("Force mode: discarding uncommitted changes")
                self.git_manager.reset_to("HEAD", mode="hard")
            else:
                raise CDEnvironmentError(
                    "Cannot pull with uncommitted changes.\n"
                    "  • Commit: cg commit -m 'message'\n"
                    "  • Discard: cg reset --hard\n"
                    "  • Force: cg pull origin --force"
                )

        # Capture pre-pull state for atomic rollback
        pre_pull_commit = git_rev_parse(self.cec_path, "HEAD")
        if not pre_pull_commit:
            raise CDEnvironmentError(
                "Cannot determine current commit state.\n"
                "The .cec repository may be corrupted. Try:\n"
                "  • Check git status: cd .cec && git status\n"
                "  • Repair repository: cd .cec && git fsck"
            )

        try:
            # Determine branch
            from ..utils.git import git_fetch, git_get_current_branch
            current_branch = branch or git_get_current_branch(self.cec_path)
            target_ref = f"{remote}/{current_branch}"

            if force:
                # Force mode: completely replace local with remote (no merge, no conflicts)
                logger.info(f"Force pulling - resetting to {target_ref}...")
                if token:
                    from ..utils.git import git_fetch_with_auth

                    git_fetch_with_auth(self.cec_path, remote, token)
                else:
                    git_fetch(self.cec_path, remote)
                git_reset_hard(self.cec_path, target_ref)
                pull_result = {
                    'fetch_output': '',
                    'merge_output': f'Reset to {target_ref}',
                    'branch': current_branch,
                }
            else:
                # Normal pull (fetch + merge)
                logger.info("Pulling from remote...")
                if token:
                    from ..utils.git import git_pull_with_auth

                    pull_result = git_pull_with_auth(
                        self.cec_path,
                        remote,
                        token,
                        branch,
                        strategy_option=strategy_option,
                    )
                else:
                    pull_result = self.git_manager.pull(remote, branch, strategy_option=strategy_option)

            # Auto-repair (restores workflows, installs nodes, downloads models)
            logger.info("Syncing environment after pull...")
            sync_result = self.sync(
                model_strategy=model_strategy,
                model_callbacks=model_callbacks,
                node_callbacks=node_callbacks,
                backend_override=backend_override,
            )

            # Check for sync failures
            if not sync_result.success:
                logger.error("Sync failed - rolling back git changes")
                git_reset_hard(self.cec_path, pre_pull_commit)
                raise CDEnvironmentError(
                    "Sync failed after pull. Git changes rolled back.\n"
                    f"Errors: {', '.join(sync_result.errors)}"
                )

            # Return both pull result and sync result for CLI to display
            return {
                **pull_result,
                'sync_result': sync_result
            }

        except Exception as e:
            # Any failure during sync - rollback git changes
            # (merge conflicts raise before this point, so don't rollback those)
            if "Merge conflict" not in str(e):
                logger.error(f"Pull failed: {e} - rolling back git changes")
                git_reset_hard(self.cec_path, pre_pull_commit)
            raise

    def _ensure_push_allowed(self) -> None:
        """Validate that this environment can push committed state."""
        from ..models.exceptions import CDEnvironmentError
        from ..models.readiness import ReadinessEnvironment

        # Check for uncommitted git changes (not workflow sync state)
        # Push only cares about git state in .cec/, not whether workflows are synced to ComfyUI
        if self.git_manager.has_uncommitted_changes():
            raise CDEnvironmentError(
                "Cannot push with uncommitted changes.\n"
                "  Run: cg commit -m 'message' first"
            )

        from ..services.environment_readiness import collect_contract_artifact_blockers

        contract_artifact_issues = collect_contract_artifact_blockers(
            cast(ReadinessEnvironment, self)
        )
        if contract_artifact_issues:
            details = [
                detail
                for issue in contract_artifact_issues
                for detail in issue.details
            ]
            detail_text = "\n".join(f"  • {detail}" for detail in details)
            raise CDEnvironmentError(
                "Cannot push with missing or invalid workflow contract API prompt files.\n"
                f"{detail_text}\n"
                "  Re-save the affected contract in ComfyGit Manager, then commit again."
            )

        # Note: Workflow issue validation happens during commit (execute_commit checks is_commit_safe).
        # By the time we reach push, all committed changes have already been validated.
        # No need to re-check workflow issues here.

    @_requires_env_lock
    def push_commits(self, remote: str = "origin", branch: str | None = None, force: bool = False) -> str:
        """Push commits to remote (requires clean working directory).

        Args:
            remote: Remote name (default: origin)
            branch: Branch to push (default: current)
            force: Use --force-with-lease for force push (default: False)

        Returns:
            Push output

        Raises:
            CDEnvironmentError: If uncommitted changes exist
            ValueError: If no remote or detached HEAD
            OSError: If push fails
        """
        self._ensure_push_allowed()

        # Push
        logger.info("Pushing commits to remote...")
        return self.git_manager.push(remote, branch, force=force)

    @_requires_env_lock
    def checkout(
        self,
        ref: str,
        strategy: RollbackStrategy | None = None,
        force: bool = False
    ) -> None:
        """Checkout commit/branch without auto-committing.

        Args:
            ref: Git reference (commit hash, branch, tag)
            strategy: Optional strategy for confirming destructive checkout
            force: If True, discard uncommitted changes without confirmation

        Raises:
            ValueError: If ref doesn't exist
            CDEnvironmentError: If uncommitted changes exist and no strategy/force
        """
        self.git_orchestrator.checkout(ref, strategy, force)

    @_requires_env_lock
    def reset(
        self,
        ref: str | None = None,
        mode: str = "hard",
        strategy: RollbackStrategy | None = None,
        force: bool = False
    ) -> None:
        """Reset HEAD to ref with git reset semantics.

        Args:
            ref: Git reference to reset to (None = HEAD)
            mode: Reset mode (hard/mixed/soft)
            strategy: Optional strategy for confirming destructive reset
            force: If True, skip confirmation

        Raises:
            ValueError: If ref doesn't exist or invalid mode
            CDEnvironmentError: If uncommitted changes exist (hard mode only)
        """
        self.git_orchestrator.reset(ref, mode, strategy, force)

    @_requires_env_lock
    def create_branch(self, name: str, start_point: str = "HEAD") -> None:
        """Create new branch at start_point.

        Args:
            name: Branch name
            start_point: Commit to branch from (default: HEAD)
        """
        self.git_orchestrator.create_branch(name, start_point)

    @_requires_env_lock
    def delete_branch(self, name: str, force: bool = False) -> None:
        """Delete branch.

        Args:
            name: Branch name
            force: Force delete even if unmerged
        """
        self.git_orchestrator.delete_branch(name, force)

    @_requires_env_lock
    def create_and_switch_branch(self, name: str, start_point: str = "HEAD") -> None:
        """Create new branch and switch to it (git checkout -b semantics).

        This is the atomic equivalent of 'git checkout -b'. It creates a branch
        from start_point and switches to it in one operation, preserving any
        uncommitted workflow changes.

        Args:
            name: Branch name to create
            start_point: Commit to branch from (default: HEAD)

        Raises:
            OSError: If branch already exists or git operations fail
        """
        self.git_orchestrator.create_and_switch_branch(name, start_point)

    @_requires_env_lock
    def switch_branch(self, branch: str, create: bool = False) -> None:
        """Switch to branch and sync environment.

        Args:
            branch: Branch name
            create: Create branch if it doesn't exist

        Raises:
            CDEnvironmentError: If uncommitted workflow changes would be overwritten
        """
        self.git_orchestrator.switch_branch(branch, create)

    def list_branches(self) -> list[GitBranch]:
        """List all branches with current branch marked.

        Returns:
            List of typed branch summaries.
        """
        from ..models.git import GitBranch

        return [
            GitBranch(name=name, is_current=is_current)
            for name, is_current in self.git_manager.list_branches()
        ]

    def get_current_branch(self) -> str | None:
        """Get current branch name.

        Returns:
            Branch name or None if detached HEAD
        """
        return self.git_manager.get_current_branch()

    def list_remotes(self) -> list[GitRemote]:
        """List configured Git remotes as typed consolidated fetch/push entries."""
        from ..models.git import GitRemote

        default_remote = self.get_tracking_remote()
        return list(
            GitRemote.from_remote_entries(
                self.git_manager.list_remotes(),
                default_remote=default_remote,
            )
        )

    @_requires_env_lock
    def add_remote(self, name: str, url: str) -> None:
        """Add a Git remote to the environment repository."""
        self.git_manager.add_remote(name, url)

    @_requires_env_lock
    def remove_remote(self, name: str) -> None:
        """Remove a Git remote from the environment repository."""
        self.git_manager.remove_remote(name)

    @_requires_env_lock
    def set_remote_url(self, name: str, url: str, *, is_push: bool = False) -> None:
        """Set the fetch or push URL for an existing Git remote."""
        self.git_manager.set_remote_url(name, url, is_push=is_push)

    def get_tracking_remote(self, branch: str | None = None) -> str | None:
        """Return the remote tracked by a branch, if configured."""
        branch = branch or self.get_current_branch()
        if not branch:
            return None

        from ..utils.git import git_config_get

        remote = git_config_get(self.cec_path, f"branch.{branch}.remote")
        return remote if remote else None

    @_requires_env_lock
    def fetch_remote(self, remote: str = "origin", *, token: str | None = None) -> None:
        """Fetch a remote, optionally using an HTTPS token for authentication."""
        if token:
            from ..utils.git import git_fetch_with_auth

            git_fetch_with_auth(self.cec_path, remote, token)
            return

        self.git_manager.fetch(remote)

    def get_remote_sync_status(self, remote: str = "origin", branch: str | None = None) -> GitSyncStatus:
        """Return ahead/behind information for a remote branch."""
        from ..models.git import GitSyncStatus

        return GitSyncStatus.from_dict(self.git_manager.get_sync_status(remote, branch))

    def get_remote_url(self, remote: str = "origin") -> str | None:
        """Return the configured URL for a git remote, if present."""
        from ..utils.git import git_remote_get_url

        return git_remote_get_url(self.cec_path, remote)

    @_requires_env_lock
    def pull_remote(
        self,
        remote: str = "origin",
        branch: str | None = None,
        model_strategy: str = "skip",
        *,
        token: str | None = None,
    ) -> dict:
        """Pull a remote branch and repair the environment after the pull."""
        return self.pull_and_repair(remote, branch, model_strategy, token=token)

    @_requires_env_lock
    def push_remote(
        self,
        remote: str = "origin",
        branch: str | None = None,
        *,
        force: bool = False,
        token: str | None = None,
    ) -> str:
        """Push commits to a remote, optionally using an HTTPS token."""
        if token:
            from ..utils.git import git_push_with_auth

            self._ensure_push_allowed()
            branch = branch or self.get_current_branch()
            return git_push_with_auth(self.cec_path, remote, token, branch, force)

        return self.push_commits(remote, branch, force)

    def check_remote_auth(self, remote_url: str, token: str) -> bool:
        """Return whether a token can access a remote URL from this environment."""
        from comfygit_core.git import check_remote_auth

        return check_remote_auth(self.cec_path, remote_url, token)

    @_requires_env_lock
    def merge_branch(
        self,
        branch: str,
        message: str | None = None,
        strategy_option: str | None = None,
    ) -> None:
        """Merge branch into current branch and sync environment.

        Args:
            branch: Branch to merge
            message: Custom merge commit message
            strategy_option: Optional strategy option (e.g., "ours" or "theirs" for -X flag)
        """
        self.git_orchestrator.merge_branch(branch, message, strategy_option)

    def validate_merge(
        self,
        branch: str,
        workflow_resolutions: dict,
    ) -> MergeValidation:
        """Validate merge compatibility before execution.

        Checks for node version conflicts that would occur if the merge
        proceeded with the given workflow resolutions.

        Args:
            branch: Branch to merge
            workflow_resolutions: Dict mapping workflow names to "take_base" or "take_target"

        Returns:
            MergeValidation with is_compatible flag and any conflicts
        """
        from ..merging.merge_validator import MergeValidator
        from ..utils.git import git_show
        from ..utils.toml_compat import tomllib

        # Load configs from both branches
        pyproject_path = Path("pyproject.toml")
        base_content = git_show(self.cec_path, "HEAD", pyproject_path)
        target_content = git_show(self.cec_path, branch, pyproject_path)

        base_config = tomllib.loads(base_content) if base_content else {}
        target_config = tomllib.loads(target_content) if target_content else {}

        validator = MergeValidator()
        return validator.validate(base_config, target_config, workflow_resolutions)

    @_requires_env_lock
    def execute_atomic_merge(
        self,
        branch: str,
        workflow_resolutions: dict,
    ) -> MergeResult:
        """Execute merge with atomic semantics and semantic pyproject merging.

        This method:
        1. Starts git merge without committing
        2. Resolves workflow files per user choices (--ours/--theirs)
        3. Builds merged pyproject.toml using semantic rules
        4. Commits the merge
        5. Syncs environment (nodes, deps, workflows)

        If any step fails, rolls back to pre-merge state.

        Args:
            branch: Branch to merge
            workflow_resolutions: Dict mapping workflow names to "take_base" or "take_target"

        Returns:
            MergeResult with success status and details
        """
        from ..merging.atomic_executor import AtomicMergeExecutor
        from ..merging.merge_validator import MergeValidator
        from ..models.merge_plan import MergePlan
        from ..utils.git import git_show
        from ..utils.toml_compat import tomllib

        # Load configs to compute final workflow set
        pyproject_path = Path("pyproject.toml")
        base_content = git_show(self.cec_path, "HEAD", pyproject_path)
        target_content = git_show(self.cec_path, branch, pyproject_path)

        base_config = tomllib.loads(base_content) if base_content else {}
        target_config = tomllib.loads(target_content) if target_content else {}

        # Compute final workflow set
        validator = MergeValidator()
        validation = validator.validate(base_config, target_config, workflow_resolutions)

        # Build merge plan
        plan = MergePlan(
            target_branch=branch,
            base_ref="HEAD",
            workflow_resolutions=workflow_resolutions,
            final_workflow_set=validation.merged_workflow_set,
            node_conflicts=validation.conflicts,
            is_compatible=validation.is_compatible,
        )

        # Execute atomic merge
        executor = AtomicMergeExecutor(
            repo_path=self.cec_path,
            pyproject_manager=self.pyproject,
            workspace_path=self.workspace_paths.root,
        )

        result = executor.execute(plan)

        # If merge succeeded, sync environment
        if result.success:
            old_nodes = self.pyproject.nodes.get_existing()
            self.git_orchestrator._sync_environment_after_git(old_nodes)

        return result

    @_requires_env_lock
    def revert_commit(self, commit: str) -> None:
        """Revert a commit by creating new commit that undoes it.

        Args:
            commit: Commit hash to revert
        """
        self.git_orchestrator.revert_commit(commit)

    def get_commit_history(self, limit: int = 10, rev_range: str | None = None) -> list[GitCommitSummary]:
        """Get commit history for this environment.

        Args:
            limit: Maximum number of commits to return
            rev_range: Optional Git revision range (e.g. ``origin/main..HEAD``)

        Returns:
            List of typed commit summaries.
        """
        from ..models.git import GitCommitSummary

        return [
            GitCommitSummary.from_dict(commit)
            for commit in self.git_manager.get_version_history(limit, rev_range)
        ]

    def sync_model_paths(self) -> dict | None:
        """Ensure model symlink is configured for this environment.

        Returns:
            Status dictionary
        """
        logger.debug(f"Configuring model symlink for environment '{self.name}'")
        try:
            self.model_symlink_manager.create_symlink()
            return {
                "status": "linked",
                "target": str(self.global_models_path),
                "link": str(self.models_path)
            }
        except Exception as e:
            logger.error(f"Failed to configure model symlink: {e}")
            raise

    # TODO wrap subprocess completed process instance
    def run(
        self,
        args: list[str] | None = None,
        *,
        backend_override: str | None = None,
    ) -> subprocess.CompletedProcess:
        """Run ComfyUI in this environment.

        Args:
            args: Arguments to pass to ComfyUI
            backend_override: Non-persistent PyTorch backend override used for
                this launched process.

        Returns:
            CompletedProcess
        """
        python = self.uv_manager.python_executable
        comfyui_args = list(args or [])
        if self.get_torch_backend_status().backend == "cpu" and "--cpu" not in comfyui_args:
            comfyui_args = ["--cpu", *comfyui_args]

        cmd = [str(python), "main.py"] + comfyui_args

        child_env = os.environ.copy()
        child_env["COMFYGIT_ENV_NAME"] = self.name
        child_env["COMFYGIT_CG_RUN_SUPERVISOR"] = "1"
        if backend_override:
            child_env[ACTIVE_TORCH_BACKEND_OVERRIDE_ENV] = backend_override

        logger.info(f"Starting ComfyUI with: {' '.join(cmd)}")
        return run_command(
            cmd,
            cwd=self.comfyui_path,
            capture_output=False,
            timeout=None,
            env=child_env,
        )

    # =====================================================
    # Node Management
    # =====================================================

    def list_nodes(self) -> list[NodeInfo]:
        """List all custom nodes in this environment.

        Returns:
            List of NodeInfo objects for all installed custom nodes
        """
        nodes_dict = self.pyproject.nodes.get_existing()
        return list(nodes_dict.values())

    @_requires_env_lock
    def add_node(
        self,
        identifier: str,
        is_development: bool = False,
        no_test: bool = False,
        force: bool = False,
        confirmation_strategy: ConfirmationStrategy | None = None,
        strict: bool = False,
        extras: list[str] | None = None,
        all_extras: bool = False,
        resolve_with_overlays: bool = False,
    ) -> NodeInfo:
        """Add a custom node to the environment.

        Args:
            identifier: Registry ID or GitHub URL (supports @version)
            is_development: Track as development node
            no_test: Skip dependency resolution testing
            force: Force replacement of existing nodes
            confirmation_strategy: Strategy for confirming replacements
            strict: If True, fail on dependency conflicts instead of auto-resolving
            extras: Optional list of extras to install during sync
            all_extras: Install all optional extras during sync
            resolve_with_overlays: If True, resolve with all active/extra overlays.
                                   If False, node sync defaults to pytorch-only overlays.

        Raises:
            CDNodeNotFoundError: If node not found
            CDNodeConflictError: If node has dependency conflicts
            CDEnvironmentError: If node with same name already exists
        """
        add_kwargs = {}
        if resolve_with_overlays:
            add_kwargs["skip_optional_overlays"] = False

        return self.node_manager.add_node(
            identifier,
            is_development=is_development,
            no_test=no_test,
            force=force,
            confirmation_strategy=confirmation_strategy,
            strict=strict,
            extras=extras,
            all_extras=all_extras,
            **add_kwargs,
        )

    @_requires_env_lock
    def link_development_node(
        self,
        identifier: str,
        source_path: Path | str,
        *,
        name: str | None = None,
        replace_existing: bool = False,
        force: bool = False,
    ) -> NodeDevLinkResult:
        """Convert or add a custom node as a symlinked development checkout."""
        self.git_manager.ensure_gitignore_entry("backups/")
        return self.node_manager.link_development_node(
            identifier,
            source_path,
            name=name,
            replace_existing=replace_existing,
            force=force,
        )

    @_requires_env_lock
    def preview_add_node_dependency_changes(self, identifier: str) -> DependencyResolutionPreview:
        """Preview lockfile dependency changes for adding a node."""
        return self.node_manager.preview_add_node_dependency_changes(identifier)

    @_requires_env_lock
    def apply_reviewed_node_dependency_changes(
        self,
        identifier: str,
        acceptance: DependencyResolutionAcceptance,
    ) -> DependencyResolutionApplyResult:
        """Apply a reviewed node install if the accepted dependency preview is current."""
        return self.node_manager.apply_reviewed_dependency_changes(identifier, acceptance)

    @_requires_env_lock
    def install_nodes_with_progress(
        self,
        node_ids: list[str],
        callbacks: NodeInstallCallbacks | None = None,
        extras: list[str] | None = None,
        all_extras: bool = False,
        resolve_with_overlays: bool = False,
    ) -> tuple[int, list[tuple[str, str]]]:
        """Install multiple nodes with callback support for progress tracking.

        Args:
            node_ids: List of node identifiers to install
            callbacks: Optional callbacks for progress feedback
            extras: Optional list of extras to install during sync
            all_extras: Install all optional extras during sync
            resolve_with_overlays: If True, resolve node installs with all overlays.

        Returns:
            Tuple of (success_count, failed_nodes)
            where failed_nodes is a list of (node_id, error_message) tuples

        Raises:
            CDNodeNotFoundError: If a node is not found
        """
        if callbacks and callbacks.on_batch_start:
            callbacks.on_batch_start(len(node_ids))

        success_count = 0
        failed = []

        for idx, node_id in enumerate(node_ids):
            if callbacks and callbacks.on_node_start:
                callbacks.on_node_start(node_id, idx + 1, len(node_ids))

            try:
                self.add_node(
                    node_id,
                    extras=extras,
                    all_extras=all_extras,
                    resolve_with_overlays=resolve_with_overlays,
                )
                success_count += 1
                if callbacks and callbacks.on_node_complete:
                    callbacks.on_node_complete(node_id, True, None)
            except Exception as e:
                failed.append((node_id, str(e)))
                if callbacks and callbacks.on_node_complete:
                    callbacks.on_node_complete(node_id, False, str(e))

        if callbacks and callbacks.on_batch_complete:
            callbacks.on_batch_complete(success_count, len(node_ids))

        return success_count, failed

    @_requires_env_lock
    def remove_node(
        self,
        identifier: str,
        untrack_only: bool = False,
        resolve_with_overlays: bool = False,
    ) -> NodeRemovalResult:
        """Remove a custom node.

        Args:
            identifier: Node identifier or name
            untrack_only: If True, only remove from pyproject.toml without touching filesystem
            resolve_with_overlays: If True, resolve post-removal sync with all active/extra
                                   overlays. If False, node sync defaults to pytorch-only overlays.

        Returns:
            NodeRemovalResult: Details about the removal

        Raises:
            CDNodeNotFoundError: If node not found
        """
        return self.node_manager.remove_node(
            identifier,
            untrack_only=untrack_only,
            skip_optional_overlays=not resolve_with_overlays,
        )

    @_requires_env_lock
    def remove_nodes_with_progress(
        self,
        node_ids: list[str],
        callbacks: NodeInstallCallbacks | None = None,
        resolve_with_overlays: bool = False,
    ) -> tuple[int, list[tuple[str, str]]]:
        """Remove multiple nodes with callback support for progress tracking.

        Args:
            node_ids: List of node identifiers to remove
            callbacks: Optional callbacks for progress feedback
            resolve_with_overlays: If True, resolve node removals with all overlays.

        Returns:
            Tuple of (success_count, failed_nodes)
            where failed_nodes is a list of (node_id, error_message) tuples

        Raises:
            CDNodeNotFoundError: If a node is not found
        """
        if callbacks and callbacks.on_batch_start:
            callbacks.on_batch_start(len(node_ids))

        success_count = 0
        failed = []

        for idx, node_id in enumerate(node_ids):
            if callbacks and callbacks.on_node_start:
                callbacks.on_node_start(node_id, idx + 1, len(node_ids))

            try:
                self.remove_node(node_id, resolve_with_overlays=resolve_with_overlays)
                success_count += 1
                if callbacks and callbacks.on_node_complete:
                    callbacks.on_node_complete(node_id, True, None)
            except Exception as e:
                failed.append((node_id, str(e)))
                if callbacks and callbacks.on_node_complete:
                    callbacks.on_node_complete(node_id, False, str(e))

        if callbacks and callbacks.on_batch_complete:
            callbacks.on_batch_complete(success_count, len(node_ids))

        return success_count, failed

    @_requires_env_lock
    def update_node(
        self,
        identifier: str,
        confirmation_strategy: ConfirmationStrategy | None = None,
        no_test: bool = False,
        target_version: str | None = None,
    ) -> UpdateResult:
        """Update a node based on its source type.

        - Development nodes: Re-scan requirements.txt
        - Registry nodes: Update to latest version
        - Git nodes: Update to latest commit

        Args:
            identifier: Node identifier or name
            confirmation_strategy: Strategy for confirming updates (None = auto-confirm)
            no_test: Skip resolution testing
            target_version: Optional exact registry version to install

        Raises:
            CDNodeNotFoundError: If node not found
            CDEnvironmentError: If node cannot be updated
        """
        return self.node_manager.update_node(
            identifier,
            confirmation_strategy,
            no_test,
            target_version=target_version,
        )

    def check_development_node_drift(self) -> dict[str, tuple[set[str], set[str]]]:
        """Check if development nodes have requirements drift.

        Returns:
            Dict mapping node_name -> (added_deps, removed_deps)
        """
        return self.node_manager.check_development_node_drift()

    # =====================================================
    # Workflow Management
    # =====================================================

    def list_workflows(self) -> WorkflowSyncStatus:
        """List all workflows categorized by sync status.

        Returns:
            Dict with 'new', 'modified', 'deleted', and 'synced' workflow names
        """
        return self.workflow_manager.get_workflow_sync_status()

    def get_workflow_sync_status(self) -> WorkflowSyncStatus:
        """Return workflow file sync status without exposing the workflow manager."""
        return self.workflow_manager.get_workflow_sync_status()

    @_requires_env_lock
    def copy_workflows_to_manifest(self) -> dict[str, Path | str | None]:
        """Copy saved ComfyUI workflow files into tracked `.cec` workflow storage."""
        return self.workflow_manager.copy_all_workflows()

    @_requires_env_lock
    def capture_workflow(self, workflow_name: str) -> Path:
        """Capture one saved workflow into the tracked working environment.

        The workflow is copied from ComfyUI's saved workflow directory into
        `.cec/workflows`, and best-effort dependency metadata is reconciled into
        the manifest. This does not commit the snapshot or install dependencies.
        """
        return self.workflow_manager.capture_workflow(workflow_name)

    def get_workflow_status(self) -> DetailedWorkflowStatus:
        """Return analyzed workflow status without exposing the workflow manager."""
        return self.workflow_manager.get_workflow_status()

    def get_workflow_path(self, workflow_name: str) -> Path:
        """Return the ComfyUI workflow JSON path for a workflow name."""
        return self.workflow_manager.comfyui_workflows / f"{workflow_name}.json"

    def get_existing_workflow_path(self, workflow_name: str) -> Path:
        """Return an existing ComfyUI workflow JSON path.

        Raises:
            FileNotFoundError: If the workflow is not present in ComfyUI's workflow directory.
        """
        return self.workflow_manager.get_workflow_path(workflow_name)

    def invalidate_workflow_resolution_cache(self, workflow_name: str) -> None:
        """Invalidate cached workflow analysis/resolution for one workflow."""
        self.workflow_cache.invalidate(self.name, workflow_name)

    def list_workflow_models(self, workflow_name: str) -> list[ManifestWorkflowModel]:
        """Return models declared for a workflow."""
        return list(self.get_workflow_manifest_models(workflow_name))

    @_requires_env_lock
    def set_workflow_manifest_models(
        self,
        workflow_name: str,
        models: Sequence[ManifestWorkflowModel],
    ) -> None:
        """Replace manifest model declarations for one workflow."""
        self.pyproject.workflows.set_workflow_models(workflow_name, list(models))

    @_requires_env_lock
    def add_workflow_manifest_model(
        self,
        workflow_name: str,
        model: ManifestWorkflowModel,
    ) -> None:
        """Add or update one manifest model declaration for a workflow."""
        self.pyproject.workflows.add_workflow_model(workflow_name, model)

    @_requires_env_lock
    def add_manifest_model(self, model: ManifestModel) -> None:
        """Add or update one environment-scoped manifest model."""
        self.pyproject.models.add_model(model)

    @_requires_env_lock
    def set_workflow_custom_node_mapping(
        self,
        workflow_name: str,
        node_type: str,
        package_id: str | None,
    ) -> None:
        """Map a workflow node type to a package, or mark it optional when package_id is None."""
        self.pyproject.workflows.set_custom_node_mapping(workflow_name, node_type, package_id)

    @_requires_env_lock
    def remove_workflow_custom_node_mapping(
        self,
        workflow_name: str,
        node_type: str,
    ) -> bool:
        """Remove a custom-node mapping for one workflow."""
        return self.pyproject.workflows.remove_custom_node_mapping(workflow_name, node_type)

    def update_workflow_model_criticality(
        self,
        workflow_name: str,
        model_identifier: str,
        criticality: str,
    ) -> bool:
        """Update model criticality for a workflow dependency."""
        return self.workflow_manager.update_model_criticality(
            workflow_name=workflow_name,
            model_identifier=model_identifier,
            new_criticality=criticality,
        )

    def add_workflow_model_dependency(
        self,
        workflow_name: str,
        *,
        model_hash: str | None = None,
        relative_path: str | None = None,
        criticality: str = "required",
    ) -> ManifestWorkflowModel:
        """Declare an indexed local model as a manual workflow dependency."""
        return self.workflow_manager.add_existing_model_to_workflow(
            workflow_name=workflow_name,
            model_hash=model_hash,
            relative_path=relative_path,
            criticality=criticality,
        )

    def remove_workflow_model_dependency(
        self,
        workflow_name: str,
        *,
        model_hash: str | None = None,
        relative_path: str | None = None,
    ) -> bool:
        """Remove a manually declared workflow model dependency."""
        return self.workflow_manager.remove_manual_model_from_workflow(
            workflow_name=workflow_name,
            model_hash=model_hash,
            relative_path=relative_path,
        )

    def get_workflow_failed_downloads(self, workflow_name: str) -> list[ManifestWorkflowModel]:
        """Return workflow models with source intent that remain unresolved."""
        return [
            model
            for model in self.list_workflow_models(workflow_name)
            if model.status == "unresolved" and model.sources
        ]

    def get_workflow_package_aliases(self) -> Mapping[str, str]:
        """Return global node package alias metadata used during workflow resolution."""
        return self.workflow_manager.get_package_aliases()

    def analyze_workflow_dependencies(
        self,
        workflow_name: str,
    ) -> tuple[WorkflowDependencies, ResolutionResult]:
        """Analyze and resolve one saved workflow without applying fixes or downloads."""
        return self.workflow_manager.analyze_and_resolve_workflow(workflow_name)

    def analyze_workflow_json(
        self,
        workflow_data: Mapping[str, object],
        *,
        workflow_name: str = "unsaved",
    ) -> tuple[WorkflowDependencies, ResolutionResult]:
        """Analyze and resolve workflow JSON that has not necessarily been saved yet."""
        return self.workflow_manager.analyze_and_resolve_workflow_json(
            workflow_data,
            workflow_name=workflow_name,
        )

    def resolve_workflow_dependencies(
        self,
        dependencies: WorkflowDependencies,
    ) -> ResolutionResult:
        """Resolve pre-analyzed workflow dependencies without mutating the manifest."""
        return self.workflow_manager.resolve_dependencies(dependencies)

    @_requires_env_lock
    def fix_workflow_resolution(
        self,
        result: ResolutionResult,
        node_strategy: NodeResolutionStrategy | None = None,
        model_strategy: ModelResolutionStrategy | None = None,
    ) -> ResolutionResult:
        """Apply node/model resolution strategies and persist their manifest choices."""
        return self.workflow_manager.fix_resolution(result, node_strategy, model_strategy)

    @_requires_env_lock
    def update_workflow_model_paths(self, result: ResolutionResult) -> int:
        """Sync workflow JSON model paths from an existing resolution result."""
        return self.workflow_manager.update_workflow_model_paths(result)

    def search_workflow_node_packages(
        self,
        query: str,
        *,
        include_registry: bool = True,
        limit: int = 10,
    ) -> list[ScoredPackageMatch]:
        """Search node packages for workflow resolution without exposing the resolver."""
        return self.workflow_manager.search_node_packages(
            query,
            include_registry=include_registry,
            limit=limit,
        )

    def resolve_workflow_node_packages(
        self,
        node: WorkflowNode,
        context: NodeResolutionContext,
    ) -> list[ResolvedNodePackage] | None:
        """Resolve one workflow node type without exposing the resolver object."""
        return self.workflow_manager.resolve_node_packages(
            node,
            context,
        )

    def get_model_download_directory(self) -> Path:
        """Return the workspace model directory used by model downloads."""
        return self.model_downloader.models_dir

    def download_model_request(
        self,
        request: DownloadRequest,
        progress_callback=None,
    ) -> DownloadResult:
        """Download a model using the environment's configured downloader."""
        return self.model_downloader.download(request, progress_callback)

    def search_workflow_models(
        self,
        query: str,
        *,
        node_type: str | None = None,
        limit: int = 9,
    ) -> list[ScoredMatch]:
        """Search indexed models for workflow resolution without exposing the workflow manager."""
        return self.workflow_manager.search_models(query, node_type, limit)

    @_requires_env_lock
    def mark_workflow_model_download_resolved(
        self,
        workflow_name: str,
        *,
        filename: str,
        model_hash: str,
    ) -> bool:
        """Mark a workflow download intent as resolved after a model download succeeds."""
        return self.workflow_manager.mark_model_download_resolved_by_filename(
            workflow_name,
            filename=filename,
            model_hash=model_hash,
        )

    def resolve_workflow(
        self,
        name: str,
        node_strategy: NodeResolutionStrategy | None = None,
        model_strategy: ModelResolutionStrategy | None = None,
        fix: bool = True,
        download_callbacks: BatchDownloadCallbacks | None = None
    ) -> ResolutionResult:
        """Resolve workflow dependencies - orchestrates analysis and resolution.

        Args:
            name: Workflow name to resolve
            node_strategy: Strategy for resolving missing nodes
            model_strategy: Strategy for resolving ambiguous/missing models
            fix: Attempt to fix unresolved issues with strategies
            download_callbacks: Optional callbacks for batch download progress (CLI provides)

        Returns:
            ResolutionResult with changes made

        Raises:
            FileNotFoundError: If workflow not found
        """
        # Analyze and resolve workflow (both cached for performance)
        _, result = self.workflow_manager.analyze_and_resolve_workflow(name)

        # Apply auto-resolutions (reconcile with pyproject.toml)
        self.workflow_manager.apply_resolution(result)

        # Check if there are any unresolved issues
        if result.has_issues and fix:
            # Fix issues with strategies (progressive writes: models AND nodes saved immediately)
            result = self.workflow_manager.fix_resolution(
                result,
                node_strategy,
                model_strategy
            )

        # Execute pending downloads if any download intents exist
        if result.has_download_intents:
            result.download_results = self.workflow_manager.execute_pending_downloads(result, download_callbacks)

            # After successful downloads, update workflow JSON with resolved paths
            # Re-resolve to get fresh model data (cached, so minimal cost)
            if result.download_results and any(dr.success for dr in result.download_results):
                _, fresh_result = self.workflow_manager.analyze_and_resolve_workflow(name)
                self.workflow_manager.update_workflow_model_paths(fresh_result)

        return result

    def get_uninstalled_nodes(self, workflow_name: str | None = None) -> list[str]:
        """Get list of node package IDs referenced in workflows but not installed.

        Compares nodes referenced in workflow sections against installed nodes
        to identify which nodes need installation.

        Returns:
            List of node package IDs that are referenced in workflows but not installed.
            Empty list if all workflow nodes are already installed.

        Example:
            >>> env.resolve_workflow("my_workflow")
            >>> missing = env.get_uninstalled_nodes()
            >>> # ['rgthree-comfy', 'comfyui-depthanythingv2', ...]
        """
        # Get all node IDs referenced in workflows
        workflow_node_ids = set()
        if workflow_name:
            if workflow := self.pyproject.workflows.get_workflow(workflow_name):
                workflows = {workflow_name: workflow}
            else:
                logger.warning(f"Workflow '{workflow_name}' not found")
                return []
        else:
            workflows = self.pyproject.workflows.get_all_with_resolutions()

        for workflow_data in workflows.values():
            node_list = workflow_data.get('nodes', [])
            workflow_node_ids.update(node_list)

        logger.debug(f"Workflow node references: {workflow_node_ids}")

        # Get installed node IDs
        installed_nodes = self.pyproject.nodes.get_existing()
        installed_node_ids = set(installed_nodes.keys())
        logger.debug(f"Installed nodes: {installed_node_ids}")

        # Find nodes referenced in workflows but not installed. Existing
        # manifests may contain exact installed aliases such as custom_nodes
        # directory names, so resolve those before reporting missing packages.
        uninstalled_ids = [
            node_id
            for node_id in workflow_node_ids
            if not resolve_installed_node_alias(node_id, installed_nodes)
        ]
        logger.debug(f"Uninstalled nodes: {uninstalled_ids}")

        return uninstalled_ids

    def get_unused_nodes(self, exclude: list[str] | None = None) -> list[NodeInfo]:
        """Get installed nodes not referenced by any workflow.

        Uses the same auto-resolution flow as status command to ensure we capture
        all nodes actually needed by workflows, including those from custom_node_map.

        Args:
            exclude: Optional list of package IDs to exclude from pruning

        Returns:
            List of NodeInfo for unused nodes that can be safely removed

        Example:
            >>> unused = env.get_unused_nodes()
            >>> # [NodeInfo(registry_id='old-node'), ...]
            >>> # Or with exclusions:
            >>> unused = env.get_unused_nodes(exclude=['keep-this-node'])
        """
        # Get workflow status (triggers auto-resolution with caching)
        workflow_status = self.workflow_manager.get_workflow_status()

        # Aggregate packages from all workflows
        all_needed_packages = set()
        for workflow_analysis in workflow_status.analyzed_workflows:
            for resolved_node in workflow_analysis.resolution.nodes_resolved:
                # Only count non-optional nodes with actual package IDs
                if resolved_node.package_id and not resolved_node.is_optional:
                    all_needed_packages.add(resolved_node.package_id)

        logger.debug(f"Packages needed by workflows: {all_needed_packages}")

        # Get installed nodes
        installed_nodes = self.pyproject.nodes.get_existing()
        installed_node_ids = set(installed_nodes.keys())
        logger.debug(f"Installed nodes: {installed_node_ids}")

        # Calculate unused = installed - needed
        unused_ids = installed_node_ids - all_needed_packages

        # Apply exclusions
        if exclude:
            unused_ids -= set(exclude)
            logger.debug(f"After exclusions: {unused_ids}")

        return [installed_nodes[nid] for nid in unused_ids]

    @_requires_env_lock
    def update_node_criticality(self, node_identifier: str, criticality: str) -> bool:
        """Update package-level custom-node criticality.

        Custom-node criticality is a user-declared deployment/readiness signal.
        It is not inferred from workflow graph usage because custom nodes may
        affect runtime behavior through hooks, extensions, or side effects.
        """
        return self.pyproject.nodes.set_criticality(node_identifier, criticality)

    @_requires_env_lock
    def prune_unused_nodes(
        self,
        exclude: list[str] | None = None,
        callbacks: NodeInstallCallbacks | None = None
    ) -> tuple[int, list[tuple[str, str]]]:
        """Remove unused nodes from environment.

        Args:
            exclude: Package IDs to keep even if unused
            callbacks: Progress callbacks

        Returns:
            Tuple of (success_count, failed_removals)
        """
        unused = self.get_unused_nodes(exclude=exclude)

        if not unused:
            return (0, [])

        # Use existing batch removal
        node_ids = [node.registry_id or node.name for node in unused]
        return self.remove_nodes_with_progress(node_ids, callbacks)

    def has_committable_changes(self) -> bool:
        """Check if there are any committable changes (workflows OR git).

        This is the clean API for determining if a commit is possible.
        Checks both workflow file sync status AND git uncommitted changes.

        Returns:
            True if there are committable changes, False otherwise
        """
        # Check workflow file changes (new/modified/deleted workflows)
        workflow_status = self.workflow_manager.get_workflow_status()
        has_workflow_changes = workflow_status.sync_status.has_changes

        # Check git uncommitted changes (pyproject.toml, uv.lock, etc.)
        has_git_changes = self.git_manager.has_uncommitted_changes()

        return has_workflow_changes or has_git_changes

    @_requires_env_lock
    def commit(self, message: str | None = None) -> None:
        """Commit changes to git repository.

        Args:
            message: Optional commit message

        Raises:
            OSError: If git commands fail
        """
        return self.git_manager.commit_all(message)

    @_requires_env_lock
    def execute_commit(
        self,
        workflow_status: DetailedWorkflowStatus | None = None,
        message: str | None = None,
        allow_issues: bool = False,
    ) -> None:
        """Execute commit using cached or provided analysis.

        Args:
            message: Optional commit message
            allow_issues: Allow committing even with unresolved issues
        """
        # Use provided analysis or prepare a new one
        if not workflow_status:
            workflow_status = self.workflow_manager.get_workflow_status()

        # Check if changes are safe to commit (no unresolved issues)
        if not workflow_status.is_commit_safe and not allow_issues:
            logger.error("Cannot commit with unresolved issues. Use --allow-issues to force.")
            return

        # Commit can be responsible for cleanup even when the only pending
        # change is a stale tracked workflow_api artifact.
        with self.pyproject.manifest.edit() as edit:
            cleanup_result = self.workflow_manager.cleanup_orphaned_workflow_state(
                config=edit.config,
            )
            if cleanup_result["workflow_entries"] > 0:
                # Clean up orphaned models after workflow sections are removed.
                edit.cleanup_model_orphans()
                edit.mark_changed()

        # Check if there are any changes to commit (workflows OR git)
        has_workflow_changes = workflow_status.sync_status.has_changes
        has_git_changes = self.git_manager.has_uncommitted_changes()

        if not has_workflow_changes and not has_git_changes:
            logger.error("No changes to commit")
            return

        # Apply auto-resolutions to pyproject.toml for workflows with changes
        # BATCHED MODE: Load config once, pass through all operations, save once
        logger.info("Committing all changes...")
        with self.pyproject.manifest.edit() as edit:
            config = edit.config

            for wf_analysis in workflow_status.analyzed_workflows:
                if (
                    wf_analysis.sync_state in ("new", "modified")
                    or self.workflow_manager.resolution_changes_manifest(
                        wf_analysis.resolution,
                        config=config,
                    )
                ):
                    # Apply resolution results to pyproject (in-memory mutations)
                    self.workflow_manager.apply_resolution(wf_analysis.resolution, config=config)
                    edit.mark_changed()

            # Clean up orphaned workflow entries and workflow API prompt artifacts.
            # This handles BOTH:
            # 1. Committed workflows deleted from ComfyUI (detected by sync_status.deleted)
            # 2. Resolved-but-never-committed workflows deleted from ComfyUI (only in pyproject)
            cleanup_result = self.workflow_manager.cleanup_orphaned_workflow_state(config=config)
            if cleanup_result["workflow_entries"] > 0:
                logger.debug(f"Removed {cleanup_result['workflow_entries']} workflow section(s)")

                # Clean up orphaned models (must run AFTER workflow sections are removed).
                edit.cleanup_model_orphans()
                edit.mark_changed()

        logger.info("Copying workflows from ComfyUI to .cec...")
        copy_results = self.workflow_manager.copy_all_workflows()
        copied_count = len([r for r in copy_results.values() if r and r != "deleted"])
        logger.debug(f"Copied {copied_count} workflow(s)")

        self.commit(message)

    # =====================================================
    # Public Snapshots and Readiness
    # =====================================================

    def get_manifest_snapshot(self) -> EnvironmentManifestSnapshot:
        """Return a typed read-only projection of the current manifest."""
        with self.read_manifest_snapshot() as snapshot:
            return snapshot

    @contextmanager
    def read_manifest_snapshot(self) -> Iterator[EnvironmentManifestSnapshot]:
        """Capture manifest and related artifacts under a short shared lock.

        Do not await, mutate the environment, or execute a prompt in this scope.
        A new detached snapshot is loaded each time; no stale-cache fallback is
        used when a writer is active.
        """
        with self._operation_lock.read():
            yield self.pyproject.get_manifest_snapshot(force_reload=True)

    def list_manifest_nodes(self) -> Mapping[str, NodeInfo]:
        """Return tracked manifest nodes without exposing the manifest manager."""
        return self.get_manifest_snapshot().nodes

    def get_manifest_node(self, identifier: str) -> NodeInfo | None:
        """Return one tracked manifest node by package identifier."""
        return self.get_manifest_snapshot().get_node(identifier)

    def list_manifest_workflows(self) -> Mapping[str, ManifestWorkflowEntry]:
        """Return tracked manifest workflows without exposing the manifest manager."""
        return self.get_manifest_snapshot().workflows

    def get_manifest_workflow(self, name: str) -> ManifestWorkflowEntry | None:
        """Return one tracked manifest workflow entry by name."""
        return self.get_manifest_snapshot().get_workflow(name)

    def list_manifest_models(self) -> Mapping[str, ManifestModel]:
        """Return tracked manifest models without exposing the manifest manager."""
        return self.get_manifest_snapshot().models

    def get_manifest_model(self, model_hash: str) -> ManifestModel | None:
        """Return one tracked manifest model by hash."""
        return self.get_manifest_snapshot().get_model(model_hash)

    def get_workflow_manifest_models(self, workflow_name: str) -> tuple[ManifestWorkflowModel, ...]:
        """Return models declared for a workflow in the manifest."""
        return self.get_manifest_snapshot().get_workflow_models(workflow_name)

    def get_workflow_custom_node_map(self, workflow_name: str) -> Mapping[str, str | bool]:
        """Return custom-node mappings declared for a workflow in the manifest."""
        return self.get_manifest_snapshot().get_workflow_custom_node_map(workflow_name)

    def has_uncommitted_git_changes(self) -> bool:
        """Return whether the tracked environment repository has uncommitted changes."""
        return self.git_manager.has_uncommitted_changes()

    def get_model_source_candidates(self, model_hash: str) -> tuple[ModelSourceCandidate, ...]:
        """Return indexed model source hints in readiness candidate form."""
        from ..models.readiness import ModelSourceCandidate

        candidates: list[ModelSourceCandidate] = []
        seen_urls: set[str] = set()
        for source in self.workspace.get_model_sources(model_hash):
            if not source.url or source.url in seen_urls:
                continue
            seen_urls.add(source.url)
            candidates.append(ModelSourceCandidate(type=source.type, url=source.url))
        return tuple(candidates)

    @_requires_env_lock
    def get_readiness(self, *, include_blocking: bool = True) -> EnvironmentReadiness:
        """Return reusable readiness and provenance checks for this environment."""
        from ..models.readiness import ReadinessEnvironment
        from ..services.environment_readiness import build_environment_readiness

        return build_environment_readiness(
            cast(ReadinessEnvironment, self),
            include_blocking=include_blocking,
        )

    # =====================================================
    # Runtime Helpers
    # =====================================================

    def get_venv_python(self) -> Path | None:
        """Return this environment's virtualenv Python executable, if present."""
        from ..utils.filesystem import get_venv_python

        return get_venv_python(self.path)

    # =====================================================
    # Workflow Contract Management
    # =====================================================

    def get_workflow_execution_contract(self, workflow_name: str) -> WorkflowExecutionContract | None:
        """Get the saved execution contract for a workflow."""
        return self.pyproject.workflows.get_execution_contract(workflow_name)

    @_requires_env_lock
    def set_workflow_execution_contract(
        self,
        workflow_name: str,
        contract: WorkflowExecutionContract,
        api_prompt_data: dict | None = None,
    ) -> None:
        """Create or replace the saved execution contract for a workflow."""
        if api_prompt_data is not None:
            rel_path = _workflow_api_prompt_relpath(workflow_name)
            api_prompt_path = self.cec_path / rel_path
            api_prompt_path.parent.mkdir(parents=True, exist_ok=True)
            with api_prompt_path.open("w", encoding="utf-8") as handle:
                json.dump(api_prompt_data, handle, indent=2)
                handle.write("\n")

            contract.api_prompt_file = rel_path.as_posix()
            contract.api_prompt_source = "comfyui_frontend"
            contract.api_prompt_generated_by = "comfygit-manager"
            contract.api_prompt_generated_at = datetime.now(UTC).isoformat().replace("+00:00", "Z")
        self.pyproject.workflows.set_execution_contract(workflow_name, contract)

    @_requires_env_lock
    def remove_workflow_execution_contract(self, workflow_name: str) -> bool:
        """Remove the saved execution contract for a workflow."""
        contract = self.pyproject.workflows.get_execution_contract(workflow_name)
        removed = self.pyproject.workflows.remove_execution_contract(workflow_name)
        if removed and contract is not None and contract.api_prompt_file:
            api_prompt_path = self.cec_path / contract.api_prompt_file
            try:
                if api_prompt_path.exists() and api_prompt_path.is_file():
                    api_prompt_path.unlink()
            except OSError as exc:
                logger.warning(
                    "Failed to remove API prompt artifact for workflow '%s': %s",
                    workflow_name,
                    exc,
                )
        return removed

    # =====================================================
    # Model Source Management
    # =====================================================

    @_requires_env_lock
    def add_model_source(self, identifier: str, url: str) -> ModelSourceResult:
        """Add a download source URL to a model.

        Args:
            identifier: Model hash or filename
            url: Download URL for the model

        Returns:
            ModelSourceResult with success status and model details
        """
        return self.model_manager.add_model_source(identifier, url)

    @_requires_env_lock
    def remove_model_source(self, identifier: str, url: str) -> ModelSourceResult:
        """Remove a download source URL from a model.

        Args:
            identifier: Model hash or filename
            url: Download URL to remove

        Returns:
            ModelSourceResult with success status and model details
        """
        return self.model_manager.remove_model_source(identifier, url)

    def get_models_without_sources(self) -> list[ModelSourceStatus]:
        """Get all models in pyproject that don't have download sources.

        Returns:
            List of ModelSourceStatus objects with model and local availability
        """
        return self.model_manager.get_models_without_sources()

    # =====================================================
    # Constraint Management
    # =====================================================

    def add_constraint(self, package: str) -> None:
        """Add a constraint dependency."""
        self.pyproject.uv_config.add_constraint(package)

    def remove_constraint(self, package: str) -> bool:
        """Remove a constraint dependency."""
        return self.pyproject.uv_config.remove_constraint(package)

    def list_constraints(self) -> list[str]:
        """List constraint dependencies."""
        return self.pyproject.uv_config.get_constraints()

    # ===== Python Dependency Management =====

    def add_dependencies(
        self,
        packages: list[str] | None = None,
        requirements_file: Path | None = None,
        upgrade: bool = False,
        group: str | None = None,
        dev: bool = False,
        optional: str | None = None,
        editable: bool = False,
        bounds: str | None = None,
        no_build_isolation: bool = False
    ) -> dict:
        """Add Python dependencies to the environment.

        Uses uv add to add packages to [project.dependencies] and install them.
        Applies package substitutions from package_config.toml (e.g., opencv-python
        is automatically replaced with opencv-contrib-python-headless).

        Args:
            packages: List of package specifications (e.g., ['requests>=2.0.0', 'pillow'])
            requirements_file: Path to requirements.txt file to add packages from
            upgrade: Whether to upgrade existing packages
            group: Dependency group name (e.g., 'optional-cuda')
            dev: Add to dev dependencies
            optional: Optional dependency extra name (project.optional-dependencies)
            editable: Install as editable (for local development)
            bounds: Version specifier style ('lower', 'major', 'minor', 'exact')
            no_build_isolation: Disable build isolation for specified packages

        Returns:
            Dict with:
                - output: UV command output
                - substitutions: Dict of {original: substituted} for any packages that were replaced

        Raises:
            UVCommandError: If uv add fails
            ValueError: If neither packages nor requirements_file is provided
        """
        if not packages and not requirements_file:
            raise ValueError("Either packages or requirements_file must be provided")

        substitutions: dict[str, str] = {}
        final_packages: list[str] | None = None

        # If requirements file provided, read and parse it
        if requirements_file:
            final_packages = self._read_requirements_file(requirements_file)
        elif packages:
            final_packages = list(packages)

        # Apply package substitutions
        if final_packages:
            transformed_packages = []
            for pkg in final_packages:
                substituted = self.package_config.apply_substitution(pkg)
                if substituted != pkg:
                    substitutions[pkg] = substituted
                    logger.info(f"Package substitution: {pkg} -> {substituted}")
                transformed_packages.append(substituted)
            final_packages = transformed_packages

        # First record the portable dependency change without solving against
        # this machine. Sync below applies local overlays and PyTorch backend
        # configuration through the normal environment materialization path.
        add_output = self.uv_manager.add_dependency(
            packages=final_packages,
            requirements_file=None,  # We've already parsed it
            upgrade=False,
            group=group,
            dev=dev,
            optional=optional,
            editable=editable,
            bounds=bounds,
            no_build_isolation=no_build_isolation,
            frozen=True,
        )

        sync_output = self.uv_manager.sync_project(
            pytorch_manager=getattr(self, "pytorch_manager", None),
            group=group,
            dev=dev,
            extras=[optional] if optional else None,
            upgrade=upgrade,
        )

        output = "\n".join(part for part in (add_output, sync_output) if part)
        return {"output": output, "substitutions": substitutions}

    def _read_requirements_file(self, requirements_file: Path) -> list[str]:
        """Read and parse a requirements.txt file.

        Strips comments and handles basic formatting.

        Args:
            requirements_file: Path to requirements.txt

        Returns:
            List of requirement strings
        """
        requirements = []
        with open(requirements_file, encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                # Skip -r includes (recursive requirements)
                if line.startswith('-r '):
                    continue
                # Skip other pip flags
                if line.startswith('-'):
                    continue
                # Strip inline comments
                if '#' in line:
                    line = line.split('#', 1)[0].strip()
                if line:
                    requirements.append(line)
        return requirements

    def remove_dependencies(self, packages: list[str]) -> dict:
        """Remove Python dependencies from the environment.

        Uses uv remove to remove packages from [project.dependencies] and uninstall them.
        Safely handles packages that don't exist in dependencies.

        Args:
            packages: List of package names to remove

        Returns:
            Dict with 'removed' (list of packages removed) and 'skipped' (list of packages not in deps)

        Raises:
            UVCommandError: If uv remove fails for existing packages
        """
        return self.uv_manager.remove_dependency(packages=packages)

    def list_dependencies(self, all: bool = False) -> dict[str, list[str]]:
        """List project dependencies.

        Args:
            all: If True, include all dependency groups. If False, only base dependencies.

        Returns:
            Dictionary mapping group name to list of dependencies.
            Base dependencies are always under "dependencies" key and appear first.
        """
        base_deps = self.pyproject.manifest.list_project_dependencies()

        result = {"dependencies": base_deps}

        if all:
            dep_groups = self.pyproject.manifest.list_dependency_groups()
            result.update(dep_groups)

        return result

    # =====================================================
    # Export/Import
    # =====================================================

    def export_environment(
        self,
        output_path: Path,
        callbacks: ExportCallbacks | None = None,
        allow_issues: bool = False
    ) -> Path:
        """Export environment as .tar.gz bundle.

        Args:
            output_path: Path for output tarball
            callbacks: Optional callbacks for warnings/progress
            allow_issues: Allow export even with unresolved workflow issues

        Returns:
            Path to created tarball

        Raises:
            CDExportError: If environment has uncommitted changes or unresolved issues (unless allow_issues)
        """
        from ..managers.export_import_manager import ExportImportManager
        from ..models.exceptions import CDExportError, ExportErrorContext
        from ..models.shared import ModelWithoutSourceInfo

        readiness = self.get_readiness(include_blocking=True)

        for issue in readiness.blocking_issues:
            if issue.type == "uncommitted_workflows":
                context = ExportErrorContext(uncommitted_workflows=issue.details)
                raise CDExportError(issue.message, context=context)

            if issue.type == "uncommitted_git_changes":
                context = ExportErrorContext(uncommitted_git_changes=True)
                raise CDExportError(issue.message, context=context)

            if issue.type == "unresolved_issues" and not allow_issues:
                context = ExportErrorContext(has_unresolved_issues=True)
                raise CDExportError(issue.message, context=context)

        if callbacks and readiness.warnings.models_without_sources:
            callbacks.on_models_without_sources([
                ModelWithoutSourceInfo(
                    filename=warning.filename,
                    hash=warning.hash or "",
                    workflows=list(warning.workflows),
                )
                for warning in readiness.warnings.models_without_sources
            ])

        # Auto-populate git info for dev nodes before export
        self._auto_populate_dev_node_git_info(callbacks)

        # Create export
        manager = ExportImportManager(self.cec_path, self.comfyui_path)
        return manager.create_export(output_path, self.pyproject)

    def _auto_populate_dev_node_git_info(
        self,
        callbacks: ExportCallbacks | None = None
    ) -> None:
        """Auto-populate git info (repository/branch/pinned_commit) for dev nodes.

        Called during export to capture git state for dev nodes that have git remotes.
        This enables teammates to clone from the same repository.

        Dev nodes without git remotes will trigger a callback notification but
        will still be exported (they just can't be shared).
        """
        from ..analyzers.node_git_analyzer import get_node_git_info

        nodes = self.pyproject.nodes.get_existing()
        updates: list[tuple[str, str | None, str | None, str | None, str]] = []

        for identifier, node_info in nodes.items():
            if node_info.source != 'development':
                continue

            node_path = self.custom_nodes_path / node_info.name
            if not node_path.exists():
                continue

            # Get git info from the node's directory
            git_info = get_node_git_info(node_path)

            if git_info is None:
                # Not a git repo - notify callback
                no_git_callback = getattr(callbacks, 'on_dev_node_no_git', None)
                if callable(no_git_callback):
                    no_git_callback(node_info.name)
                continue

            if not git_info.remote_url:
                # Git repo but no remote - notify callback
                no_git_callback = getattr(callbacks, 'on_dev_node_no_git', None)
                if callable(no_git_callback):
                    no_git_callback(node_info.name)
                continue

            updates.append((
                identifier,
                git_info.remote_url,
                git_info.branch,
                git_info.commit,
                node_info.name,
            ))

        if not updates:
            return

        with self.pyproject.manifest.edit() as edit:
            for identifier, remote_url, branch, commit, node_name in updates:
                if edit.update_node_git_info(
                    identifier,
                    repository=remote_url,
                    branch=branch,
                    pinned_commit=commit,
                ):
                    logger.info(f"Captured git info for dev node '{node_name}'")

    def finalize_import(
        self,
        model_strategy: str = "all",
        callbacks: ImportCallbacks | None = None,
        no_manager: bool = False,
        *,
        create_import_commit: bool = True,
        fail_on_sync_errors: bool = False,
    ) -> None:
        """Complete import setup after .cec extraction.

        Assumes .cec directory is already populated (from tarball or git).

        Phases:
            1. Clone/restore ComfyUI from cache and configure PyTorch
            2. Initialize git repository
            3. Copy workflows to ComfyUI user directory
            4. Sync dependencies, custom nodes, and workflows (via sync())
            5. Prepare and resolve models based on strategy

        Args:
            model_strategy: "all", "required", or "skip"
            callbacks: Optional progress callbacks
            no_manager: Skip comfygit-manager install/registration (headless mode)
            create_import_commit: Commit final import/materialization changes
            fail_on_sync_errors: Raise if sync reports or raises dependency errors

        Raises:
            ValueError: If ComfyUI already exists or .cec not properly initialized
        """
        from ..caching.comfyui_cache import ComfyUICacheManager, ComfyUISpec
        from ..utils.comfyui_ops import (
            clone_comfyui,
            normalize_comfyui_commit_sha,
            normalize_comfyui_repository,
            verify_comfyui_checkout,
        )

        logger.info(f"Finalizing import for environment: {self.name}")

        # Verify environment state
        if self.comfyui_path.exists():
            raise ValueError("Environment already has ComfyUI - cannot finalize import")

        # Strip local filesystem path sources (editable dev installs from export machine)
        self._strip_local_path_sources()

        # Ensure overlay migration runs before finalize-import sync.
        # This guarantees .local-uv-config -> overlays/.local.toml happens prior to sync().
        _ = self.overlay_manager

        # Phase 1: Clone or restore ComfyUI from cache
        comfyui_cache = ComfyUICacheManager(cache_base_path=self.workspace_paths.cache)

        # Read ComfyUI version from pyproject.toml
        try:
            comfyui_manifest_version = self.pyproject.manifest.get_comfyui_version()
            comfyui_version = comfyui_manifest_version.version
            comfyui_version_type = comfyui_manifest_version.version_type
            comfyui_repository = normalize_comfyui_repository(
                comfyui_manifest_version.repository
            )
            comfyui_commit_sha = normalize_comfyui_commit_sha(
                comfyui_manifest_version.commit_sha
            )
        except Exception as e:
            logger.warning(f"Could not read comfyui_version from pyproject.toml: {e}")
            comfyui_version = None
            comfyui_version_type = None
            comfyui_repository = normalize_comfyui_repository(None)
            comfyui_commit_sha = None

        if comfyui_version:
            version_desc = f"{comfyui_version_type} {comfyui_version}" if comfyui_version_type else comfyui_version
            logger.debug(f"Using comfyui_version from pyproject: {version_desc}")

        # Auto-detect version type if not specified
        if not comfyui_version_type and comfyui_version:
            if comfyui_version.startswith('v'):
                comfyui_version_type = "release"
            elif comfyui_version in ("main", "master"):
                comfyui_version_type = "branch"
            else:
                comfyui_version_type = "commit"
            logger.debug(f"Auto-detected version type: {comfyui_version_type}")

        # Create version spec
        spec = ComfyUISpec(
            version=comfyui_version or "main",
            version_type=comfyui_version_type or "branch",
            commit_sha=comfyui_commit_sha,
            repository=comfyui_repository,
        )
        clone_ref = comfyui_commit_sha or comfyui_version

        # Check cache first
        cached_path = comfyui_cache.get_cached_comfyui(spec)

        if cached_path:
            if callbacks:
                callbacks.on_phase("restore_comfyui", f"Restoring ComfyUI {spec.version} from cache...")
            logger.info(f"Restoring ComfyUI {spec.version} from cache")
            shutil.copytree(cached_path, self.comfyui_path)
            actual_commit = verify_comfyui_checkout(
                self.comfyui_path,
                repository=comfyui_repository,
                commit_sha=comfyui_commit_sha,
            )
            logger.info(
                "Verified cached ComfyUI origin and commit %s",
                actual_commit[:12],
            )
        else:
            if callbacks:
                callbacks.on_phase("clone_comfyui", f"Cloning ComfyUI {spec.version}...")
            logger.info(
                "Cloning ComfyUI %s from %s",
                clone_ref or "default branch",
                comfyui_repository,
            )
            clone_comfyui(
                self.comfyui_path,
                clone_ref,
                repository=comfyui_repository,
            )

            # Cache the fresh clone
            commit_sha = verify_comfyui_checkout(
                self.comfyui_path,
                repository=comfyui_repository,
                commit_sha=comfyui_commit_sha,
            )
            if commit_sha:
                spec.commit_sha = commit_sha
                comfyui_cache.cache_comfyui(spec, self.comfyui_path)
                logger.info(f"Cached ComfyUI {spec.version} ({commit_sha[:7]})")
            else:
                logger.warning(f"Could not determine commit SHA for ComfyUI {spec.version}")

        # Extract builtin nodes for imported environment
        from ..utils.builtin_extractor import extract_comfyui_builtins

        try:
            if callbacks:
                callbacks.on_phase("extract_builtins", "Extracting builtin nodes...")

            builtins_path = self.cec_path / "comfyui_builtins.json"

            # Check if already exists (from exported bundle)
            if builtins_path.exists():
                logger.debug("Builtin config already exists from export, skipping extraction")
            else:
                extract_comfyui_builtins(self.comfyui_path, builtins_path)
                logger.info(f"Extracted builtin nodes to {builtins_path.name}")
        except Exception as e:
            logger.warning(f"Failed to extract builtin nodes: {e}")
            logger.warning("Workflow resolution will fall back to global static config")

        # Extract folder paths from ComfyUI installation
        from ..utils.folder_paths_extractor import extract_folder_paths

        try:
            folder_paths_json = self.cec_path / "comfyui_folder_paths.json"
            extract_folder_paths(self.comfyui_path, folder_paths_json)
            logger.info(f"Extracted folder paths to {folder_paths_json.name}")
        except Exception as e:
            logger.warning(f"Failed to extract folder paths: {e}")
            logger.warning("Model category validation will fall back to static config")

        # Extract model loader widget metadata from ComfyUI installation
        from ..utils.model_loader_extractor import extract_comfyui_model_loaders

        try:
            model_loaders_json = self.cec_path / "comfyui_model_loaders.json"
            extract_comfyui_model_loaders(self.comfyui_path, model_loaders_json)
            logger.info(f"Extracted model loaders to {model_loaders_json.name}")
        except Exception as e:
            logger.warning(f"Failed to extract model loader metadata: {e}")
            logger.warning("Model loader detection will fall back to static config")

        # Remove ComfyUI's default models directory (will be replaced with symlink)
        models_dir = self.comfyui_path / "models"
        if models_dir.exists() and not models_dir.is_symlink():
            rmtree(models_dir)

        # Remove ComfyUI's default input/output directories (will be replaced with symlinks)
        from ..utils.symlink_utils import is_link

        input_dir = self.comfyui_path / "input"
        if input_dir.exists() and not is_link(input_dir):
            rmtree(input_dir)
            logger.debug("Removed ComfyUI's default input directory during import")

        output_dir = self.comfyui_path / "output"
        if output_dir.exists() and not is_link(output_dir):
            rmtree(output_dir)
            logger.debug("Removed ComfyUI's default output directory during import")

        # Create symlinks for user content and system nodes
        self.user_content_manager.create_directories()
        self.user_content_manager.create_symlinks()

        # Create default ComfyUI user settings (skip templates panel on first launch)
        user_settings_dir = self.comfyui_path / "user" / "default"
        user_settings_dir.mkdir(parents=True, exist_ok=True)
        settings_file = user_settings_dir / "comfy.settings.json"
        if not settings_file.exists():
            settings_file.write_text('{"Comfy.TutorialCompleted": true}')
            logger.debug("Created default user settings (skip templates panel)")

        # Auto-register comfygit-manager if present in imported environment
        # (replaces legacy symlink system - manager is now per-environment)
        if no_manager:
            self._prepare_headless_import()
            logger.info("Manager registration skipped during import (--no-manager)")
        else:
            self._register_imported_manager()

        # Phase 1.5: Probe PyTorch and configure backend
        # Read Python version from .python-version file
        python_version_file = self.cec_path / ".python-version"
        python_version = python_version_file.read_text(encoding='utf-8').strip() if python_version_file.exists() else "3.12"

        if self.torch_backend:
            from ..managers.pytorch_backend_manager import PyTorchBackendManager

            if callbacks:
                callbacks.on_phase("probe_pytorch", "Detecting PyTorch backend...")

            # Migrate schema v1 environments (strips embedded PyTorch config)
            migrated = self.pyproject.migrate_pytorch_config()
            if migrated:
                logger.info("Migrated imported environment to schema v2")

            # Use dry-run probe to detect backend
            pytorch_manager = PyTorchBackendManager(self.cec_path)
            resolved_backend = pytorch_manager.probe_and_set_backend(python_version, self.torch_backend)

            if self.torch_backend == "auto":
                logger.info(f"PyTorch backend: auto-detected as {resolved_backend}")
            else:
                logger.info(f"PyTorch backend: {resolved_backend}")

        # Phase 2: Setup git repository
        # For git imports: .git already exists with remote, just ensure gitignore
        # For tarball imports: .git doesn't exist, initialize fresh repo
        git_existed = (self.cec_path / ".git").exists()

        if callbacks:
            phase_msg = "Ensuring git configuration..." if git_existed else "Initializing git repository..."
            callbacks.on_phase("init_git", phase_msg)

        if git_existed:
            # Git import case: preserve existing repo, just ensure gitignore
            logger.info("Git repository already exists (imported from git), preserving remote and history")
            self.git_manager._create_gitignore()
            self.git_manager.ensure_git_identity()
        else:
            # Tarball import case: initialize fresh repo
            logger.info("Initializing new git repository")
            self.git_manager.initialize_environment_repo("Imported environment")

        # Phase 3: Copy workflows
        if callbacks:
            callbacks.on_phase("copy_workflows", "Setting up workflows...")

        workflows_src = self.cec_path / "workflows"
        workflows_dst = self.comfyui_path / "user" / "default" / "workflows"
        workflows_dst.mkdir(parents=True, exist_ok=True)

        if workflows_src.exists():
            for workflow_file in workflows_src.glob("*.json"):
                shutil.copy2(workflow_file, workflows_dst / workflow_file.name)
                if callbacks:
                    callbacks.on_workflow_copied(workflow_file.name)

        shared_overlays = [
            info.name
            for info in self.overlay_manager.list_overlays()
            if not info.is_local
        ]
        if shared_overlays:
            overlay_msg = (
                f"Detected {len(shared_overlays)} shared overlay(s): "
                f"{', '.join(shared_overlays)}"
            )
            logger.info(overlay_msg)
            if callbacks:
                callbacks.on_phase("detect_overlays", overlay_msg)

        # Phase 3.5: Ensure ComfyUI base requirements are present
        # Web-exported environments may have dependencies=[] since the exact
        # requirements.txt isn't known at export time. Add them now from the
        # freshly cloned ComfyUI so uv sync installs everything.
        comfyui_reqs = self.comfyui_path / "requirements.txt"
        if comfyui_reqs.exists():
            current_deps = self.pyproject.manifest.list_project_dependencies()
            if not current_deps:
                logger.info("Adding ComfyUI requirements (empty dependencies detected)...")
                if callbacks:
                    callbacks.on_phase("add_requirements", "Adding ComfyUI base requirements...")
                requirements = read_comfyui_requirements_with_supplements(comfyui_reqs)
                self.uv_manager.add_requirements_with_sources(requirements, frozen=True)

        # Phase 4: Sync dependencies, custom nodes, and workflows
        # This single sync() call handles all dependency installation, node syncing, and workflow restoration
        if callbacks:
            callbacks.on_phase("sync_environment", "Syncing dependencies and custom nodes...")

        try:
            # During import, don't remove ComfyUI builtins (fresh clone has example files)
            # Enable verbose to show real-time uv output during dependency installation
            sync_result = self.sync(remove_extra_nodes=False, sync_callbacks=callbacks, verbose=True, mark_complete=False)
            if sync_result.success and sync_result.nodes_installed and callbacks:
                for node_name in sync_result.nodes_installed:
                    callbacks.on_node_installed(node_name)
            elif not sync_result.success and callbacks:
                for error in sync_result.errors:
                    callbacks.on_error(f"Node sync: {error}")
            if fail_on_sync_errors and not sync_result.success:
                error_text = "; ".join(sync_result.errors) if sync_result.errors else "unknown sync error"
                raise RuntimeError(f"Environment sync failed during materialization: {error_text}")
            if fail_on_sync_errors:
                missing_required_nodes = self._missing_required_materialized_nodes()
                if missing_required_nodes:
                    raise RuntimeError(
                        "Environment materialization is missing required custom nodes: "
                        + ", ".join(missing_required_nodes)
                    )
        except Exception as e:
            if callbacks:
                callbacks.on_error(f"Node sync failed: {e}")
            if fail_on_sync_errors:
                raise

        # Phase 5: Prepare and resolve models
        if callbacks:
            callbacks.on_phase("resolve_models", f"Resolving workflows ({model_strategy} strategy)...")

        # Resolve workflows with download intents
        from ..models.workflow import BatchDownloadCallbacks
        from ..strategies.auto import AutoModelStrategy, AutoNodeStrategy

        download_failures = []

        # Create download callbacks adapter if import callbacks provided
        download_callbacks = None
        if callbacks:
            download_callbacks = BatchDownloadCallbacks(
                on_batch_start=callbacks.on_download_batch_start,
                on_file_start=callbacks.on_download_file_start,
                on_file_progress=callbacks.on_download_file_progress,
                on_file_complete=callbacks.on_download_file_complete,
                on_batch_complete=callbacks.on_download_batch_complete
            )

        for download in self.model_manager.download_environment_models(model_strategy, download_callbacks):
            if not download.success:
                download_failures.append(("environment", download.filename))

        # Always prepare models to copy sources from global table, even for "skip"
        # This ensures download intents are preserved for later resolution
        workflows_with_intents = self.model_manager.prepare_import_with_model_strategy(model_strategy)

        # Only auto-resolve if not "skip" strategy
        workflows_to_resolve = [] if model_strategy == "skip" else workflows_with_intents

        # prepare_import_with_model_strategy() may update pyproject model entries.
        # Invalidate per-workflow cache entries so resolve_workflow() sees fresh
        # download intents instead of stale session-cached resolutions.
        for workflow_name in workflows_to_resolve:
            self.workflow_cache.invalidate(self.name, workflow_name)

        for workflow_name in workflows_to_resolve:
            try:
                manifest_downloads = self.workflow_manager.execute_manifest_downloads(
                    workflow_name,
                    self.pyproject.workflows.get_workflow_models(workflow_name),
                    download_callbacks,
                )
                result = self.resolve_workflow(
                    name=workflow_name,
                    model_strategy=AutoModelStrategy(),
                    node_strategy=AutoNodeStrategy(),
                    download_callbacks=download_callbacks
                )

                # Track successful vs failed downloads from actual download results
                all_downloads = [*manifest_downloads, *result.download_results]
                successful_downloads = sum(1 for dr in all_downloads if dr.success)
                failed_downloads = [
                    (workflow_name, dr.filename)
                    for dr in all_downloads
                    if not dr.success
                ]

                download_failures.extend(failed_downloads)

                if callbacks:
                    callbacks.on_workflow_resolved(workflow_name, successful_downloads)

            except Exception as e:
                download_failures.append((workflow_name, str(e)))
                if callbacks:
                    callbacks.on_error(f"Failed to resolve {workflow_name}: {e}")

        # Report download failures
        if download_failures and callbacks:
            callbacks.on_download_failures(download_failures)

        if download_failures and model_strategy != "skip":
            from ..models.exceptions import CDModelDownloadError

            formatted_failures = ", ".join(
                f"{model_name} (from {workflow_name})"
                for workflow_name, model_name in download_failures
            )
            raise CDModelDownloadError(
                f"{len(download_failures)} model(s) failed to download: {formatted_failures}",
                failures=download_failures
            )

        if no_manager:
            self._set_headless_marker()

        # Mark environment as fully initialized
        from ..utils.environment_cleanup import mark_environment_complete
        mark_environment_complete(self.cec_path)

        # Phase 7: Commit all changes from import process
        # This captures: workflows copied, nodes synced, models resolved, pyproject updates
        if create_import_commit and self.git_manager.has_uncommitted_changes():
            self.git_manager.commit_with_identity("Imported environment", add_all=True)
            logger.info("Committed import changes")

        logger.info("Import finalization completed successfully")

    def _strip_local_path_sources(self) -> None:
        """Remove uv sources with local filesystem paths (editable dev installs).

        When environments are exported from dev machines, they may contain
        [tool.uv.sources.package-name] entries with local paths like:
            path = "/home/dev/projects/my-package"
            editable = true

        These paths don't exist on other machines and cause sync failures.
        This method removes any source entries that use local paths.
        """
        removed = self.pyproject.strip_local_path_sources()
        for pkg_name in removed:
            logger.info(f"Stripped local path source: {pkg_name}")

    def _untrack_uvlock_if_tracked(self) -> None:
        """Untrack uv.lock if it was previously tracked in git.

        uv.lock is now gitignored (platform-specific PyTorch variants).
        For existing environments where it was tracked, untrack it.
        """
        from ..utils.git import _git

        # Check if uv.lock is tracked
        result = _git(
            ["ls-files", "uv.lock"],
            self.cec_path,
            check=False
        )
        if result.stdout.strip() == "uv.lock":
            # Untrack without deleting the file
            _git(["rm", "--cached", "uv.lock"], self.cec_path, check=False)
            logger.info("Untracked uv.lock (now gitignored)")

    def _untrack_generated_metadata_if_tracked(self) -> None:
        """Untrack generated ComfyUI metadata files if previously committed."""
        from ..utils.git import _git

        for filename in (
            "comfyui_builtins.json",
            "comfyui_folder_paths.json",
            "comfyui_model_loaders.json",
        ):
            result = _git(
                ["ls-files", filename],
                self.cec_path,
                check=False
            )
            if result.stdout.strip() == filename:
                _git(["rm", "--cached", filename], self.cec_path, check=False)
                logger.info(f"Untracked {filename} (now gitignored)")

    # =====================================================
    # Metadata Management
    # =====================================================

    def refresh_metadata(self) -> dict:
        """Refresh extracted metadata from ComfyUI installation.

        Re-extracts builtins, folder paths, and model loader metadata for the current environment.
        Useful after upgrading ComfyUI or to fix missing metadata files
        for environments created before v0.3.12.

        Returns:
            dict with keys:
                - builtins_refreshed: bool
                - folder_paths_refreshed: bool
                - model_loaders_refreshed: bool
                - builtins_count: int (number of builtin nodes)
                - folder_mappings_count: int (number of folder mappings)
                - model_loaders_count: int (number of generated model loader nodes)

        Raises:
            ValueError: If ComfyUI installation is missing or invalid
        """
        from ..utils.builtin_extractor import extract_comfyui_builtins
        from ..utils.folder_paths_extractor import extract_folder_paths
        from ..utils.model_loader_extractor import extract_comfyui_model_loaders

        if not self.comfyui_path.exists():
            raise ValueError(f"ComfyUI not found at {self.comfyui_path}")

        result = {
            "builtins_refreshed": False,
            "folder_paths_refreshed": False,
            "model_loaders_refreshed": False,
            "builtins_count": 0,
            "folder_mappings_count": 0,
            "model_loaders_count": 0,
        }

        # Re-extract builtins
        builtins_path = self.cec_path / "comfyui_builtins.json"
        try:
            output = extract_comfyui_builtins(self.comfyui_path, builtins_path)
            result["builtins_refreshed"] = True
            result["builtins_count"] = output.get("metadata", {}).get("total_nodes", 0)
            logger.info(f"Refreshed comfyui_builtins.json ({result['builtins_count']} nodes)")
        except Exception as e:
            logger.warning(f"Failed to refresh builtins: {e}", exc_info=True)

        # Re-extract folder paths
        folder_paths_path = self.cec_path / "comfyui_folder_paths.json"
        try:
            output = extract_folder_paths(self.comfyui_path, folder_paths_path)
            result["folder_paths_refreshed"] = True
            result["folder_mappings_count"] = output.get("metadata", {}).get("total_folder_types", 0)
            logger.info(f"Refreshed comfyui_folder_paths.json ({result['folder_mappings_count']} folder types)")
        except Exception as e:
            logger.warning(f"Failed to refresh folder paths: {e}", exc_info=True)

        # Re-extract model loaders
        model_loaders_path = self.cec_path / "comfyui_model_loaders.json"
        try:
            output = extract_comfyui_model_loaders(self.comfyui_path, model_loaders_path)
            result["model_loaders_refreshed"] = True
            result["model_loaders_count"] = output.get("metadata", {}).get("total_model_loaders", 0)
            logger.info(
                f"Refreshed comfyui_model_loaders.json "
                f"({result['model_loaders_count']} model loaders)"
            )
        except Exception as e:
            logger.warning(f"Failed to refresh model loaders: {e}", exc_info=True)

        if any((
            result["builtins_refreshed"],
            result["folder_paths_refreshed"],
            result["model_loaders_refreshed"],
        )):
            self.workflow_cache.invalidate(self.name)
            if "workflow_manager" in self.__dict__:
                self.workflow_manager.refresh_runtime_metadata_context()

        return result
